#- animación de gráfico mediante transición entre gráficos
#------ Nuevo gganimate: https://gganimate.com/

# install.packages("gganimate")
# install.packages("gapminder")

library(gganimate)
library(gapminder)

theme_set(theme_bw())

#- gráfico estático
p <- ggplot(gapminder, aes(x = gdpPercap, y = lifeExp, size = pop, colour = continent)) +
      geom_point(show.legend = TRUE, alpha = 0.7) +
      scale_color_viridis_d() +
      scale_size(range = c(2, 12)) +
      scale_x_log10() +
     labs(x = "GDP per capita", y = "Life expectancy")
p


#- animación
p + transition_time(year) +
  labs(title = "Year: {frame_time}")

#- TAREA: mirar el enlace de abajo
#- https://www.datanovia.com/en/blog/gganimate-how-to-create-plots-with-beautiful-animation-in-r/

#- we could see some more animations:
#- https://gist.github.com/thomasp85/05169ad44ddcc8ed56da6ff7bf7fbe36
#- https://gist.github.com/thomasp85/9362bbfae956f2690794abeb2c11cdcc

#- https://www.brucemeng.ca/post/animations-in-r/

#- spinning globes
# https://www.youtube.com/watch?v=VsyLrCBs0wQ
# http://spatial.ly/2017/05/spinning-globes-with-r/
