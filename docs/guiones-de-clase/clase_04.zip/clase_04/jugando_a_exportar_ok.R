#- OBJETIVO: aprender a importar y exportar datos en R

#- vamos a crear una carpeta de pruebas
fs::dir_create("pruebas")


#- ya sabemos que podemos cargar datos que tengamos en nuestro PC o directamente desde internet

#- Por ejemplo, hay un archivo .csv en esta dirección: https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv
#- podemos descargarlo con 
download.file(url = "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv", 
              destfile = "./pruebas/iris_descargado.csv")

#- ¿Cómo lo cargamos en memoria?
#- venga, primero con menús ..... pero lo normal es hacerlo con instrucciones.




#- para cargar datos en R hay multitud de paquetes
#- los paquetes que se usan en el tidyverse son: "readr" y "haven"
#- PERO, creo que es mejor que nos centremos en el paquete "rio"
#- generalmente los paquetes tienen una version de desarollo en Github, veamosla: https://github.com/leeper/rio
#- bien, vamos a usar "rio"
library(rio)
help(package = "rio")   #- aún más ayuda

#- hagamos visibles dos data.frames de R: iris y mtcars  ¿donde estaban?
iris <- iris
mtcars <- mtcars


#-------  EXPORTACION -------------------------------------------
#- vamos a exportarlos a varios formatos. la función es export(). Veamos la yuda de la f. export() apretando F1
export(iris)  #- xq no funciona?
export(iris, "./pruebas/iris.csv")  
export(iris, "./pruebas/iris.xlsx")  
export(iris, "./pruebas/iris.dta")  #- xq no funciona?  Lo borramos, si no, dará luego pb's
export(iris, "./pruebas/iris.sav")



#-------  IMPORTACION -------------------------------------------
#- venga, a importar los ficheros "my_iris"
my_iris.csv <- rio::import("./pruebas/iris.csv")
my_iris.xlsx <- rio::import("./pruebas/iris.xlsx")
class(my_iris.csv)


#- podemos importar los datos como tibble
my_iris.spss <- rio::import(file = "./pruebas/iris.sav", 
                       setclass = "tibble") #- como una tibble


#- ALGUNOS BONUS ---------------------------------------------------------------

#- Bonus 1: le añadimos un libro mas al archivo "./pruebas/iris.xlsx"
rio::export(x = iris, 
            file = here::here("pruebas", "iris.xlsx"), 
            which = "iris_2")

#- Bonus 2: (!!) exportar 2 df's en un único archivo .xlsx

rio::export(x = list(iris = iris, pinguinos = palmerpenguins::penguins), 
            file = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Bonus 3: (!!) importar una hoja/libro especifica de un archivo .xlsx
iris_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"))  #- solo importa el primer libro

pinguinos_1 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"), 
                           sheet = 2)

pinguinos_2 <- rio::import(here::here("pruebas", "my_iris_pinguinos.xlsx"), 
                           sheet = "pinguinos")


#- Bonus 4: (!!!!) importamos todos los libros de un archivo .xlsx
library(readxl)
my_dfs_list <- lapply(excel_sheets(here::here("pruebas", "my_iris_pinguinos.xlsx")), 
                      read_excel,
                      path = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Bonus 5: (!!!!!!) importamos todos archivos de datos de una carpeta concreta; por ejemplo vamos a cargar en memoria de R todos los ficheros de datos que tenemos en la carpeta "pruebas"

#- importamos todos los archivos que hemos creado en "./pruebas/"
library(purrr)
my_carpeta <- here::here("pruebas")
lista_de_archivos <- fs::dir_ls(my_carpeta)  
my_dfs_list_2 <- map(lista_de_archivos, rio::import)


#- vamos a borar los archivos q hemos creado:
lista_de_archivos <- fs::dir_ls(my_carpeta)  
fs::file_delete(lista_de_archivos)


#- Volvemos a las slides_04