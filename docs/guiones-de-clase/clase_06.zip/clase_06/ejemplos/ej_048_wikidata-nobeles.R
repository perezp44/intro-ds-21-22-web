# WIKIDATA, hay que conocerla mas!!!!
#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners
#- https://www.wikidata.org/wiki/Wikidata:Main_Page



library(tidyverse)
library(wikifacts) 
#------------- query de los NOBELES
#- Los datos de Tidy Tuesday tenian los datos hasta 2016, ¿y los de 2017, 2018 y 2019?
#- hagamos una querie a Wikidata: https://query.wikidata.org/


#- con MAPITA ------------------------------------------------------------------
#People that received Nobel Prize
#defaultView:Map
SELECT DISTINCT ?person ?personLabel ?awardLabel  ?year ?lugar_nacLabel ?countryLabel ?fecha_nacimiento ?fecha_muerte ?_image ?_coordinates WHERE {
    ?person p:P166 ?statement.
    ?statement ps:P166 ?award.
    ?award wdt:P279?/wdt:P31?  wd:Q7191.
    ?person wdt:P19 ?lugar_nac. 
    ?lugar_nac wdt:P625 ?_coordinates.   # their birthplace, specifically the coordinates of their birthplace
    ?lugar_nac wdt:P17 ?country. 
    OPTIONAL {
        ?statement pq:P585 ?date.
        BIND(YEAR(?date) AS ?year)
    }
    SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
    OPTIONAL { ?person wdt:P569 ?fecha_nacimiento. }
    OPTIONAL { ?person wdt:P570 ?fecha_muerte. }
    OPTIONAL { ?person wdt:P18 ?_image. }
    # OPTIONAL { ?person wdt:P101 ?ocupacion. }
    
    
}
ORDER BY DESC (?year) (?awardLabel)



#- querrye desde R -------------------------------------------------------------
library(tidyverse)
library(wikifacts) 

query <- 
    'SELECT DISTINCT ?person ?personLabel ?awardLabel ?year ?lugar_nacLabel ?countryLabel ?fecha_nacimiento ?fecha_muerte ?_image WHERE {
    ?person p:P166 ?statement.
    ?statement ps:P166 ?award.
    ?award wdt:P279?/wdt:P31?  wd:Q7191.
    ?person wdt:P19 ?lugar_nac. 
    ?lugar_nac wdt:P17 ?country. 
    OPTIONAL {
        ?statement pq:P585 ?date.
        BIND(YEAR(?date) AS ?year)
    }
    SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
    OPTIONAL { ?person wdt:P569 ?fecha_nacimiento. }
    OPTIONAL { ?person wdt:P570 ?fecha_muerte. }
    OPTIONAL { ?person wdt:P18 ?_image. }
    # OPTIONAL { ?person wdt:P101 ?ocupacion. }
}
ORDER BY DESC (?year) (?awardLabel)'

#- mando la consulta a wikidata
#df_nobeles_wiki <- wiki_query(query)
#rio::export(df_nobeles_wiki, "./pruebas/df_nobeles_wiki.csv")

#- recupero los datos obtenidos en la consulta a Wikidata
df_orig <- readr::read_csv("./datos/df_nobeles_wiki.csv")
df <- df_orig #- voy a trabajar con df

#- vemos los países con mas Nóbeles en 2021
names(df)
aa <- df %>% count(countryLabel, year) %>% arrange(desc(year))
bb <- df %>% filter(year == 2021)


#- Wikidata mola!!!  Wikidata, hay que conocerla más!! -------------------------

#- video de 7 minutos: https://www.youtube.com/watch?v=24DOvuZWaD0
#- video más largito: https://commons.wikimedia.org/wiki/File:Querying_Wikidata_with_SPARQL_for_Absolute_Beginners.webm


#- wikidata: https://www.wikidata.org/wiki/Wikidata:Main_Page
#- wikidata Queries: https://query.wikidata.org/