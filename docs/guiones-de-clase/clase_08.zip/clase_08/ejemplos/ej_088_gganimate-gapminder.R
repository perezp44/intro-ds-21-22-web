#- animación de gráfico mediante transición entre gráficos
#------ Nuevo gganimate: https://gganimate.com/


options(scipen = 999) #- para quitar la notación científica

library(tidyverse)
library(gganimate)
library(gapminder)
library(viridis)
library(hrbrthemes)
library(plotly)

theme_set(theme_bw())

#- gráfico estático
p <- ggplot(gapminder, aes(x = gdpPercap, y = lifeExp, size = pop/1000000, colour = continent)) +
      geom_point(show.legend = TRUE, alpha = 0.7) +
      scale_color_viridis_d() +
      scale_size(range = c(1, 16)) +
      scale_x_log10() +
     labs(x = "GDP per capita", y = "Life expectancy") +
     ease_aes('linear') 

p


#- animación
p + transition_time(year) +
  labs(title = "Year: {frame_time}")


#- plotly: https://holtzy.github.io/data_analysis_website/

df <- gapminder %>% 
  filter(year == 2007) %>% 
  mutate(gdpPercap = round(gdpPercap, 0)) %>%
  mutate(pop = round(pop/1000000, 2)) %>%
  mutate(lifeExp = round(lifeExp, 1)) %>%
  mutate(country = factor(country)) %>%
  mutate(text = paste0("Country: ", country, 
                      "\nPopulation (M): ", pop, "\nLife Expectancy: ", 
                       lifeExp, "\nGdp per capita: ", gdpPercap)) 


p <- df %>% 
  ggplot( aes(x = gdpPercap, y = lifeExp, size = pop, color = continent, text = text)) +
  geom_point(alpha = 0.7) +
  scale_size(range = c(1.4, 19), name = "Population (M)") +
  scale_color_viridis(discrete = TRUE, guide = FALSE) +
  theme_ipsum() +
  theme(legend.position="none")
p

ggplotly(p, tooltip = "text")



#- Super gráfico hecho por Jesús LLoret ----------------------------------------
#- https://stackoverflow.com/questions/59072398/how-to-render-ggplot2gganimateggflags-faster
#- https://www.toddrjones.com/blog/2021-09-10-animated-plot-tutorial/

#devtools::install_github('rensa/ggflags')
library(ggflags)
#install.packages("gifski")
library(gifski)
library(countrycode)

#Necesito añadir el codigo que relaciona el pais para poder utilizar ggflags

gapminder$code<-tolower(countrycode(gapminder$country,origin = 'country.name', destination = 'iso2c'))

#- un poco más a la tidy
gapminder <- gapminder %>% mutate(code_2 = countrycode(sourcevar = country, origin = 'country.name', destination = 'iso3c'))


#DataFrame

df <- gapminder %>%
  filter(continent == "Europe") %>%
  select(year, country, gdpPercap, lifeExp, code) %>%
  group_by(year) %>%
  arrange(year)

#Grafica 

p_extra2 <- ggplot(df, aes(x=gdpPercap, y=lifeExp, country= code)) +
  theme(text = element_text(size=20)) +
  labs(title = "Evolucion de la relacion de la Esperanza de vida con el PIBpc (1952-2007)") + 
  labs(subtitle = "Año: {closest_state}") +
  labs(caption = "Datos provenientes de gapminder dataset") +
  labs(x= "PIBpc") +
  labs(y= "Esperanza de vida") +
  theme_minimal() +
  geom_flag(size = 10) +
  transition_states(year, transition_length = 1, state_length = 1) 

p_extra2




#- TAREA: mirar el enlace de abajo
#- https://www.datanovia.com/en/blog/gganimate-how-to-create-plots-with-beautiful-animation-in-r/

#- we could see some more animations:
#- https://gist.github.com/thomasp85/05169ad44ddcc8ed56da6ff7bf7fbe36
#- https://gist.github.com/thomasp85/9362bbfae956f2690794abeb2c11cdcc

#- https://www.brucemeng.ca/post/animations-in-r/

#- spinning globes
# https://www.youtube.com/watch?v=VsyLrCBs0wQ
# http://spatial.ly/2017/05/spinning-globes-with-r/
