#- conocer un poco los colores y paletas ---------------------------------------
library(tidyverse)
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + 
  geom_point()

#- colores x nombre -----------------
aa <- as.data.frame(colours())
aa

#- mys paletas con scale_color_manual() ----------------------------------------
my_pal = c("#838383", "orange", "#00FF00", "#000000")
scales::show_col(my_pal)

p + scale_color_manual(values = my_pal)

#- RColorBrewer ----------------------------------------------------------------  
#- RColorBrewer: https://www.datanovia.com/en/blog/the-a-z-of-rcolorbrewer-palette/
library(RColorBrewer)
RColorBrewer::display.brewer.all()
RColorBrewer::display.brewer.pal(n = 8, name = 'Dark2')
RColorBrewer::display.brewer.pal(n = 8, name = 'Paired')


p + scale_color_brewer(palette = "Dark2")
p + scale_color_brewer(palette = "Paired")


my_pal2 <- RColorBrewer::brewer.pal(n = 8, name = 'Paired')
p + scale_color_manual(values = my_pal2)



#- Viridis palettes ------------------------------------------------------------ 
#- https://sjmgarnier.github.io/viridis/ 
p + viridis::scale_color_viridis(discrete = TRUE, option = "D")


#- wesanderson palettes --------------------------------------------------------
#- https://github.com/karthik/wesanderson 
library(wesanderson)
names(wes_palettes)
p + scale_color_manual(values = wes_palette("Royal2"))
#- puedes generar paletas de 100 colores
my_pal <- wes_palette("Moonrise3", 100, type = "continuous")
my_pal
image(volcano, col = my_pal)

#- paleteer pkg ----------------------------------------------------------------
#- https://github.com/EmilHvitfeldt/paletteer 
#- A comprehensive collection of color palettes in R using a common interface.
p + paletteer::scale_color_paletteer_d("nord::aurora")




#- colorfindr pkg --------------------------------------------------------------
#- https://github.com/zumbov2/colorfindr
#- This R package allows you to extract colors from various image types (currently JPEG, PNG, TIFF, SVG, BMP). 
#- Un ejemplo: https://github.com/annahensch/R-tutorials/blob/master/ggplot-on-fire.md

# Load packages (and install if needed)
pacman::p_load(colorfindr, tidyverse)

#- imagen a usar (bandera de Sudafrica)
my_url <- "https://upload.wikimedia.org/wikipedia/commons/a/af/Flag_of_South_Africa.svg"

magick::image_read(my_url)

# get & plot colors
get_colors(img = my_url , min_share = 0.05) %>% plot_colors(sort = "size")


#- make palette
my_pal <- get_colors(img = my_url, min_share = 0.05) %>% make_palette(n = 5) # here we extract 5 colors
my_pal

#- usar la paleta
library(palmerpenguins) # get the penguin data
p <- penguins %>% 
     ggplot(aes(flipper_length_mm, fill = species)) + 
        geom_density(alpha = 0.8, color = NA) 

p

p + scale_fill_manual(values = my_pal)


# Get colors and create a palette (n = 5) with foto de Tintín 
my_url <- "https://www.movieart.ch/bilder_xl/tintin-et-milou-poster-11438_0_xl.jpg"
magick::image_read(my_url)

get_colors(my_url) %>% 
  make_palette(n = 5)

# Get colors and create a palette (n = 5) with cover de NV
get_colors("https://images.coveralia.com/audio/n/Nacho_Vegas-Canciones_Populistas_(EP)-Frontal.jpg") %>% 
  make_palette(n = 5)


# Plot (5000 randomly selected pixels)
# colorines <- get_colors("https://upload.wikimedia.org/wikipedia/commons/f/f4/The_Scream.jpg")
# colorines %>% plot_colors_3d(sample_size = 5000, marker_size = 2.5, color_space = "RGB")


