#- script para la clase 08 
#- ggplot2 ----------------------------------------------------------------------------
library(tidyverse)


# enseguida continuamos con slides_06(B) pero antes RECORDAMOS un poco:
p <- ggplot(data = iris, 
            mapping = aes(x = Sepal.Length, y = Petal.Length, color = Species)) + 
         geom_point()
p
#- se pueden hacer tb cosas más "extrañas":
ggplot(iris, aes(Sepal.Length, Petal.Length, 
                   color = Petal.Length > 6)) +  geom_point()

ggplot(iris, aes(Sepal.Length, Petal.Length, 
                  color = Petal.Length > mean(Petal.Length, na.rm = TRUE))) + geom_point()


#- recuerda que podemos ir añadiendo capas: cada capa está compuesta de 3 cosas: datos, aes() y un  geom_xx
p + geom_smooth()

#- OK, easy ... PERO hoy vamos a profundizar un poco más.
#- En realidad.... cada capa está compuesta de más cosas:
#- además de datos, aes() y geom_xx, cada capa necesita/incorpora stats() y position() 
#- repito, cada capa tb tiene: stats() y position() ... y scales()
#- algunos ejemplos para intentar intuirlo
p + geom_point(position = "jitter", color = "pink", size = 0.9)
p + geom_point(position = position_jitter(width = 1.7, height = 0.3), color = "pink", size = 0.9)

p + geom_point(stat = "smooth", color = "pink", size = 0.5)


#- las opciones de cada geom_xx en: https://www.yihanwu.ca/post/geoms-and-aesthetic-parameters/
#- aún más completo: http://sape.inf.usi.ch/quick-reference/ggplot2/geom_point
#- por ejemplo geom_vline(), algunos de sus parámetros son: xintercept, size, linetype, colour, alpha
p + geom_vline(xintercept = 5.0, size = 0.7, linetype = 2, colour = "black", alpha = 0.7)


#- 3.1 títulos ------------------------------------------------------------------
p + labs(title = "Gráfico 1: Longitud del sépalo frente al pétalo",
         subtitle = "(diferenciando por especie de lirio)",
         caption = "Datos provenientes del Iris dataset",
         x = "Longitud del sépalo",
         y = "Longitud del pétalo",
         color = "Especie de lirio",
         tag = "Plot 1")

#- para quitarlos: p +  labs(title = NULL)  
#- para quitar la leyenda: p + heme(legend.position = "none")
#- bueno, en realidad hay muchas formas:
# 3 formas de quitar la leyenda
p + theme(legend.position = "none")
p + guides(color = "none", x = "none") 
p + scale_color_discrete(guide = "none")

# 3 formas de quitar el título de la leyenda
p + theme(legend.title = element_blank()) 
p + scale_color_discrete(name = NULL) 
p + labs(color = NULL)



#- posición de la leyenda (a veces la leyenda hay que moverla)
p + theme(legend.position = "none")
p + theme(legend.position = c(0.9, 0.1))
p + theme(legend.position = "bottom", legend.direction = "vertical")



#- 3.2 themes -------------------------------------------------------------------
p + theme_minimal() 

#- puedo definir mi propio theme
#- element_text(), element_rect(), element_line(), element_blank()
#- element_text()
my_theme <- theme(
  axis.text.x = element_text(colour = "blue", size = 10, angle = 180, hjust = 1.5, vjust = 0.5) ,
  axis.text.y = element_text(colour = "red", size = 12, margin = margin(r = 20)), 
  axis.title.x = element_text(color = "pink",margin = margin(t = 40), size = 22),
  #axis.title.y = element_text(margin = margin(r = 150), colour = "pink", face = "bold.italic"),
  text = element_text(size = 13, colour = "green"))


p + my_theme

#- element_rect()
p + theme(panel.background = element_rect(fill = "green", colour = "pink", 
                                         linetype = "longdash", size = 3.5))
p + theme(panel.background = element_blank())

p + theme(plot.background = element_rect(fill = "green", colour = "pink", 
                                          linetype = "longdash", size = 3.5))

#- element_line()
p + theme(panel.grid.major.x = element_line(color = "purple"))
p + theme(panel.grid.major.x = element_blank(),
          panel.grid.minor.x = element_blank())

#- plot.margin = margin()
p + theme(plot.margin = margin(t = 100, r = 0, b = 0, l = -200))


#- puedes fijar el theme
theme_set(theme_minimal())  

#- elementos del theme: https://isabella-b.com/blog/ggplot2-theme-elements-reference/  
#- https://henrywang.nl/ggplot2-theme-elements-demonstration/





#- NUEVO: empezamos con material NUEVO -----------------------------------------
# Veamos algunos elementos más: 


#- colores (pp.11) -------------------------------------------------------------
########  haz el ejemplo: ej_024b_usar-palettes 



#- 3.3 facetting (pp. 12) ------------------------------------------------------
p + facet_grid(cols = vars(Species))              #- gráficos x columnas
p + facet_grid(rows = vars(Species))              #- gráficos x filas
p + facet_wrap(vars(Species), nrow = 2, ncol = 2) #- graf x filas y columnas

########  discretizar: ntile()

df <- iris %>% mutate(qq = ntile(Petal.Length, 3))


#- 3.4 anotaciones (pp. 16) ----------------------------------------------------
# anotaciones con annotate()
p + annotate(geom = "text", x = 6, y = 2, label = "Una anotación", size = 5) +
    annotate("rect", xmin = 6, xmax = 7,ymin = -Inf, ymax = Inf, alpha = 0.2, fill = "pink") + 
    annotate("segment", x = 5, xend = 7, y = 6, yend = 8, colour = "blue")

# anotaciones con geom_text()
p + geom_text(aes(label = Petal.Length)) 
p + geom_text(aes(label = Species), size = 1.9) 
# no parece muy útil pero con un poco de imaginación/cuidado
iris_max <- iris %>% group_by(Species) %>% slice_max(Petal.Length, n = 1)
p + geom_text(data = iris_max, aes(label = Species), color = "black", size = 3) 
p + geom_text(data = iris_max, aes(label = Species), color = "black", size = 3, hjust = "left") 

# Anotaciones con geom_xx_line()
p + geom_vline(xintercept = 6)
p + geom_hline(yintercept = 5, size = 1.7, colour = "purple", linetype = "dashed")
p + geom_abline(intercept = 0.7, slope = 0.4, size = 1.9, colour = "steelblue")



#- 3.5 límites de los ejes (pp. 18) --------------------------------------------
#limites: x[4-8] y[1-7] 
p + lims(x = c(NA,6)) + lims(y = c(1,8)) + lims(color = c("setosa"))  



#- 3.6 escalas (!!) (pp. 22) ---------------------------------------------------
#- para cada par variable/estética representada en un gráfico ggplot 
#- es necesaria una escala: tendría que fijarse con las f. scale_xx()
p + scale_colour_continuous()

pp <- ggplot(iris, aes(Sepal.Length, Petal.Length)) + geom_point()
pp

pp + geom_point(aes(color = Petal.Width)) + scale_colour_continuous()

p + scale_colour_brewer(palette = 2)

p + scale_x_continuous(breaks = seq(3, 10.5, 1.5), limits = c(3, 10.5)) + 
    scale_y_continuous(breaks = seq(0, 12, 3), limits = c(0, 12), label = scales::dollar)



#- 3.7 Stats (!!!!) (pp. 25) -----------------------------------------------------
p + geom_point(stat = "identity")
p + geom_point(stat = "unique")     #- no hay muchos lirios repetidos

p + geom_point(stat = "smooth", method = "auto", size = 0.2)

p + geom_smooth(linetype = 2)
p + geom_smooth(linetype = 2, stat = "identity")


p1 <- ggplot(iris, aes(Species, Sepal.Length)) + geom_boxplot()
p1 

p1 + geom_point()
p1 + geom_point(position = "jitter")

p1 + geom_jitter()
p1 + geom_jitter((aes(colour = Species)))
p1 + geom_jitter(position = position_jitter(width = 0.15), color = "pink")

#- GOOD
p1 + geom_point(stat = "summary", fun.y = "mean", colour = "red", size = 3)


#- ejemplo (histograma)
p1 <- ggplot(iris, aes(Sepal.Length)) + geom_histogram() 
p2 <- ggplot(iris, aes(Sepal.Length))+  geom_histogram(aes(y = after_stat(count / max(count))))



library(patchwork)
p1 + p2

#- !!!!!!
p1 <- ggplot(iris) + geom_bar(aes(x = Sepal.Length))
p2 <- ggplot(iris) + geom_bar(aes(x = Sepal.Length,
               y = after_stat(count / max(count)) ))


library(patchwork)
p1 + p2

#- !!!!!!!!!!!!
p + stat_summary(fun = "mean", geom = "point", color = "black")
p + stat_summary(fun = "max", geom = "point", color = "black")



#- 3.8 Position adjustments ------- slides (B)  --------------------------------


#- 4. Combinando gráficos --------- slides (B)  --------------------------------


#- 5. Exportando gráficos --------  slides (B)  --------------------------------



#---------------------- SLIDES (C) ---------------------------------------------

#- 6. Tipos de gráficos ----------  slides (C)  --------------------------------

#- 7. Más detalles/cosas ----  mira un poco en el tutorial   -------------------

#- 8. Asistentes ggplot2 ----------  slides (B)  -------------------------------
library(ggThemeAssist)    #- install.packages("ggThemeAssist")
library(esquisse)         #- install.packages("esquisse")
library(ggannotate)       #- remotes::install_github("mattcowgill/ggannotate")
iris <- iris

p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point()

ggannotate::ggannotate(p)



#- 6. Tipos de gráficos ----------  slides (C)  ----------------------------------

#- Extensiones: https://exts.ggplot2.tidyverse.org/gallery/

#- 6.1 Histogramas

iris_backgroung <- iris %>% select(-Species)
ggplot(iris, aes(x = Sepal.Length)) +
  geom_histogram(data = iris_backgroung, fill = "grey", bins = 15) +
  geom_histogram(aes(fill = Species), bins = 15) +
  facet_grid(cols = vars(Species))

ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "stack", alpha = 0.5) 
ggplot(iris, aes(Sepal.Length, fill = Species)) + geom_density(position = "identity", alpha = 0.5) 

ggplot(iris, aes(x = Sepal.Length, y = Species)) + 
  ggridges::geom_density_ridges(aes(fill = Species), alpha = 0.5)

#- 6.2 Scatter plot

#- 6.3 Gráficos de caja (Boxplots)
# reordenar los grupos
ggplot(iris, aes(x = Species,  y = Sepal.Width)) + geom_boxplot()
ggplot(iris, aes(x = reorder(Species, Sepal.Width, mean),  y = Sepal.Width)) + geom_boxplot() +
xlab("De menor a mayor anchura del sépalo")

#- 6.4 Gráficos de barra (Boxplots)
p <- ggplot(mpg, aes(class))
p + geom_bar()
p + geom_bar(fill = "steelblue") + coord_flip()
# ya no hace falta coord_flip()
p <- ggplot(mpg, aes(y =class))
p + geom_bar()

# reordenando las categorias
df <- mpg
df <- df %>% mutate(class = forcats::as_factor(class)) #- convertimos la v. class a factor con la f. as_factor()
df <- df %>% mutate(class = forcats::fct_infreq(class)) #- fct_infreq() los niveles del factor según su frecuencia de mayor a menor
p <- ggplot(df, aes(fct_rev(class))) #- fct_rev() ordena los levels de menor a mayor
p + geom_bar(fill = "steelblue") + coord_flip()



#- 10. Gráficos interactivos -------------------------------

# lo más fácil con plotly
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) +  geom_point() + geom_smooth()

plotly::ggplotly(p)

#- Mirando en la gallery, me decidí por este:https://erblast.github.io/parcats/
library(parcats)    #- devtools::install_github("erblast/parcats")
require(easyalluvial)
iris <- iris %>% select(Species, Sepal.Length, Petal.Length)
p <- alluvial_wide(iris, max_variables = 3)
p
parcats(p, marginal_histograms = TRUE, data_input = mtcars2)



#- RMARKDOWN ------------------------------------------------------------------