#- tidygeocoder: https://github.com/ikashnitsky/dataviz-mpidr/blob/master/day5/geocoding.R
#- geolocalizar el lugar de nacimiento de la gente de la clase

library(tidyverse)
library(tidygeocoder)
library(mapview)
library(leafpop)


df <- rio::import(here::here("datos", "respuestas-cuestionario-inicial.xlsx"))

df <- df %>% janitor::clean_names()  #- limpio los nombres
#df <- df %>% tidyr::drop_na()        #- quito los NA's: bueno en realidad no hay NA's

df <- df %>% mutate(text_to_geocode = ciudad)

# now geocode -----
library(tidygeocoder)
df <- df %>% tidygeocoder::geocode(text_to_geocode, method = "osm") %>% select(- text_to_geocode)

#- lo guardamos per si de cas
# rio::export(df, here::here("datos", "students_geocoded.rds"))

df <- rio::import(here::here("datos", "students_geocoded.rds"))
                             
                             
# convert coordinates to an sf object
library(sf)
df <- df %>% sf::st_as_sf(coords = c("long", "lat"), crs = 4326)


# graficamos con mapview: https://r-spatial.github.io/mapview/index.html -------------------------
mapview::mapview(df)

#- calculamos el nº de gente que nació en el mismo lugar
df <- df %>% group_by(ciudad) %>% mutate(NN_lugar = n()) %>% ungroup()
mapview::mapview(df, cex = "NN_lugar")

#- se puede tunear el gráfico (pero a mi no me ha funcionado bien)
library(leafpop)
mapview::mapview(df, popup = popupTable(df, zcol = c("nombre", "ciudad")))


# graficamos con leaflet: https://rstudio.github.io/leaflet/  ------------------------------------

library(leaflet)
leaflet() %>% addTiles() %>% leafem::addMouseCoordinates()


leaflet(data = df) %>% addTiles() %>%
    addMarkers( popup = ~ as.character(NN_lugar), label = ~ as.character(nombre))


