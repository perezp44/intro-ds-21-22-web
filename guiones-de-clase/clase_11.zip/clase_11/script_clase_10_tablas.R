#- script para seguir el tutorial nº 8: Tablas con RMD 
library(tidyverse)
options(scipen = 999) #- para quitar la notación científica


#- cargamos datos para generar algunos resultados para mostrarlos en tablas
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/PIAAC_data_small.csv"
df_original <- read_csv(my_url)

df <- df_original

#- remotes::install_github("perezp44/pjpv2020.01")
df_aa <- pjpv2020.01::pjp_f_estadisticos_basicos(df) #- estadísticos básicos del df
df_bb <- pjpv2020.01::pjp_f_unique_values(df)        #- valores únicos de cada variable de df



#- knitr::kable() --------------------------------------------------------------
#- tablas de resultados obtenidas con dplyr y mostradas con knitr::kable() 


#- tt_1 ------------------------------------------------------------------------
#- contamos, vemos cuantas observaciones tiene cada país
df_tt_1 <- df %>% 
           count(Country)

df_tt_1 <- df %>% 
           group_by(Country) %>% 
           summarise(NN = n())

knitr::kable(df_tt_1)

knitr::kable(df_tt_1, format = "html")
knitr::kable(df_tt_1, format = "latex")
knitr::kable(df_tt_1, format = "pipe")


#- tt_2 ------------------------------------------------------------------------
#- vemos el % q representa cada país en el total de observaciones
df_tt_2 <- df %>% 
           group_by(Country) %>% 
           summarise(NN = n(), percent = n()/nrow(.) )

df_tt_2 <- df %>% 
           group_by(Country) %>%
           summarise(NN = n(), percent = NN / sum(NN))


knitr::kable(df_tt_2)
knitr::kable(df_tt_2, format = "pipe")


#- tt_3 ------------------------------------------------------------------------
#- obtenemos el % de Hombres y Mujeres en cada país) 
df_tt_3 <- df %>% 
          count(Country, Gender) %>%
          group_by(Country) %>%
          mutate(percent = n / sum(n)) %>%
          select(-n) %>%
          pivot_wider(names_from = Gender, values_from = percent) %>% 
          ungroup()

knitr::kable(df_tt_3)
knitr::kable(df_tt_3, format = "pipe")


#- tt_4 ------------------------------------------------------------------------
#- Porcentaje de Hombres y Mujeres en cada nivel educativo)
df_tt_4 <- df %>% 
           count(Education, Gender) %>% 
           group_by(Education) %>%
           mutate(percent = n / sum(n)) %>%
           select(-n) %>%
           pivot_wider(names_from = Education, values_from = percent) %>%
           ungroup()

knitr::kable(df_tt_4, format = "pipe")


#- tt_5 
#- Calculamos el salario medio por país
df_tt_5 <- df %>% 
    group_by(Country) %>% 
    summarise(W_hora_medio = mean(Wage_hour , na.rm = TRUE), 
              W_mes_medio  = mean(Wage_month, na.rm = TRUE) ) %>% 
    ungroup()

knitr::kable(df_tt_5, format = "pipe")


#- tt_6 ------------------------------------------------------------------------
#- Calculamos la media, el mínimo, el máximo y la desviación típica de Wage_month
df_tt_6 <- df %>% 
    group_by(Country) %>% 
    summarise(W_medio  = mean(Wage_month, na.rm = TRUE) ,
              W_minimo = min(Wage_month, na.rm = TRUE)  ,
              W_maximo = max(Wage_month, na.rm = TRUE)  ,
              W_sd = sd(Wage_month, na.rm = TRUE) ) %>% 
              ungroup()

knitr::kable(df_tt_6, format = "pipe")


#- tt_7 ------------------------------------------------------------------------
#-  Salario medio en España (Hombres y Mujeres)
df_tt_7 <- df %>% 
  filter(Country == "ESP") %>% 
  group_by(Gender) %>%  
  summarise(W_hora_medio = mean(Wage_hour, na.rm = TRUE), 
            W_mes_medio = mean(Wage_month, na.rm = TRUE) ) %>%
  ungroup()

knitr::kable(df_tt_7, format = "pipe")


#- tt_8 ------------------------------------------------------------------------
#-  Salario medio en los 4 los países (Hombres y Mujeres)
df_tt_8 <- df %>% 
  group_by(Country, Gender) %>% 
  summarise(W_hora_medio = mean(Wage_hour, na.rm = TRUE), 
            W_mes_medio = mean(Wage_month, na.rm = TRUE) ) %>% 
  ungroup()

knitr::kable(df_tt_8, format = "pipe")



#- tt_9 ------------------------------------------------------------------------
#- ¿Cuanto más cobran los hombres (en %)?
df_tt_9 <- df %>% 
  group_by(Country, Gender) %>% 
  summarise(W_mes_medio = mean(Wage_month, na.rm = TRUE)) %>% 
  ungroup() %>% 
  pivot_wider(names_from = Gender, values_from = W_mes_medio) %>% 
  mutate(dif_W = Male-Female, dif_percent_W = dif_W/Female)

knitr::kable(df_tt_9, format = "pipe")


#- tt_10 ------------------------------------------------------------------------
#- Numeracy Score por país y nivel de estudios. La tabla nos va a salir alargada
df_tt_10 <- df %>% 
  group_by(Country, Education) %>% 
  summarise(Numeracy_media = mean(Numeracy_score, na.rm = TRUE)) %>% 
  ungroup() 

knitr::kable(df_tt_10, format = "pipe")


#- tt_11 -----------------------------------------------------------------------
#- Hagamos la anterior tabla más ancha (Una columna para cada país)
df_tt_11 <- df_tt_10 %>% 
            pivot_wider(names_from = Education, 
                        values_from = Numeracy_media)

knitr::kable(df_tt_11, format = "pipe")


#- quiero ordenar la tabla de menor a mayor nivel educativo
df <- df %>% 
  mutate(Education = forcats::as_factor(Education))

levels(df$Education)
df %>% count(Education)


#- renombrando los levels de los factores
df <- df %>% 
  mutate(Education = forcats::fct_recode(Education,
                    "Primaria"         = "Primary",
                    "Secundaria"       = "Secondary", 
                    "Secundaria_post"  = "Upper_second",
                    "Terciaria"        = "Tertiary" )) 
levels(df$Education)
df %>% count(Education)


#- reordenando los levels de un factor
df <- df %>% 
  mutate(Education = forcats::fct_relevel(Education, 
                                  "Primaria", "Secundaria", "Secundaria_post")) 

df %>% count(Education)


#- tt_12 -----------------------------------------------------------------------
df_tt_12 <- df %>% 
  group_by(Country, Education) %>% 
  summarise(Numeracy_media = mean(Numeracy_score, na.rm = TRUE)) %>% 
  ungroup() %>%  
  pivot_wider(names_from = Education, 
              values_from = Numeracy_media) 

knitr::kable(df_tt_12, format = "pipe")


#- janitor --------------------------------------------------------------------- 
#- tablas de resultados con el pkg janitor 

#- Cuadro con el número de observaciones de cada país
df_tt_1_j <- df %>% janitor::tabyl(Country)
df_tt_1_j

#- número de Hombres y Mujeres en cada país
df_tt_3_j <- df %>% janitor::tabyl(Country, Gender)
df_tt_3_j

#- Porcentaje de Hombres y Mujeres en cada país
df_tt_3_j <- df %>% janitor::tabyl(Country, Gender) %>% 
                    janitor::adorn_percentages(denominator = "row")
df_tt_3_j

#- Porcentaje de Hombres y Mujeres en cada nivel educativo
df_tt_4_j <- df %>% janitor::tabyl(Gender, Education) %>% 
                    janitor:: adorn_percentages(denominator = "col")
df_tt_4_j


#- Hay otros paquetes con funcionalidades parecidas a `janitor`. Por ejemplo, el paquete [`freqtables`](https://github.com/brad-cannell/freqtables) o el paquete [`sjmisc`](https://strengejacke.github.io/sjmisc/index.html).

iris %>% freqtables::freq_table(Species)
iris %>% freqtables::freq_table(Species) %>% freqtables::freq_test() 

iris %>% sjmisc::frq(Species)

#- kable() más cosas -----------------------------------------------------------
#- kable() admite dar formato a algunos elementos de la tabla
knitr::kable(df_tt_12, format = "pipe",
             align = "c", 
             caption = "Numeracy Score por país",
             digits = 2, 
             format.args = list(decimal.mark = ",", big.mark = "."))


#- kableExtra pkg --------------------------------------------------------------
knitr::kable(df_tt_12) %>% 
  kableExtra::kable_styling(bootstrap_options = c("striped", "hover"))


#- scroll box
df_tt_12 %>%
  knitr::kable() %>%
  kableExtra::kable_styling(font_size = 11) %>%
  kableExtra::scroll_box(width = "50%", height = "60%")


#- podemos hacer q flote en el texto
knitr::kable(df_tt_12) %>% 
  kableExtra::kable_styling(bootstrap_options = "striped", 
                            full_width = FALSE, 
                            position = "float_right")


#- fijar columnas
knitr::kable(df_tt_12) %>%
  kableExtra::kable_styling(fixed_thead = 
                              list(enabled = T, background = "lightblue"))


#- colorines, girar ...
knitr::kable(df_tt_12) %>%
       kableExtra::kable_styling(full_width = F) %>%
       kableExtra::column_spec(1, bold = T, border_right = T) %>%
       kableExtra::column_spec(3, width = "20em", background = "yellow") %>% 
       kableExtra::row_spec(3:4, bold = T, color = "white", background = "#D7261E") %>% 
       kableExtra::row_spec(0, angle = 10)


#- un ejemplo chulo
library(kableExtra)
mtcars[1:8, 1:8] %>%
  kbl() %>%
  kable_paper(full_width = F) %>%
  column_spec(2, color = spec_color(mtcars$mpg[1:8]),
              link = "https://haozhu233.github.io/kableExtra/") %>%
  column_spec(6, color = "white",
              background = spec_color(mtcars$drat[1:8], end = 0.7),
              popover = paste("am:", mtcars$am[1:8]))


#- pkg formattable: un ejemplo -------------------------------------------------
df <- data.frame(
  id = 1:10,
  name = c("Bob", "Ashley", "James", "David", "Jenny", 
    "Hans", "Leo", "John", "Emily", "Lee"), 
  age = c(28, 27, 30, 28, 29, 29, 27, 27, 31, 30),
  grade = c("C", "A", "A", "C", "B", "B", "B", "A", "C", "C"),
  test1_score = c(8.9, 9.5, 9.6, 8.9, 9.1, 9.3, 9.3, 9.9, 8.5, 8.6),
  test2_score = c(9.1, 9.1, 9.2, 9.1, 8.9, 8.5, 9.2, 9.3, 9.1, 8.8),
  final_score = c(9, 9.3, 9.4, 9, 9, 8.9, 9.25, 9.6, 8.8, 8.7),
  registered = c(TRUE, FALSE, TRUE, FALSE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE),
  stringsAsFactors = FALSE)


library(formattable)
df %>% formattable(list(
  age = color_tile("white", "orange"),
  grade = formatter("span", style = x ~ ifelse(x == "A", 
    style(color = "green", font.weight = "bold"), NA)),
  area(col = c(test1_score, test2_score)) ~ normalize_bar("pink", 0.2),
  final_score = formatter("span",
    style = x ~ style(color = ifelse(rank(-x) <= 3, "green", "gray")),
    x ~ sprintf("%.2f (rank: %02d)", x, rank(-x))),
  registered = formatter("span",
    style = x ~ style(color = ifelse(x, "green", "red")),
    x ~ icontext(ifelse(x, "ok", "remove"), ifelse(x, "Yes", "No")))
))


#- pkg flextable: un ejemplo ---------------------------------------------------
library(flextable)

ft <- flextable::flextable(head(iris), col_keys = c("Sepal.Length", "Sepal.Width", "Petal.Length", "Petal.Width", "Species" ))

ft %>% autofit() %>%  align(align = "center", part = "all")


#- pkg gt: un ejemplo ----------------------------------------------------------
library(gt) #-remotes::install_github("rstudio/gt")

gt::gt(df_tt_4)


#- la tabla, al igual q un ggplot, se guarda en un objeto de clase "list"
gt_tbl <- df_tt_4 %>% gt()
gt_tbl

gt_tbl <- gt_tbl %>% tab_header(title = md("**Genero y nivel educativo**"),
                      subtitle = md("Porcentaje de *H y M* en cada nivel educativo"))
gt_tbl


#- pkg DT: un ejemplo ----------------------------------------------------------
DT::datatable(iris)
DT::datatable(df_tt_4)



DT::datatable(iris, filter = 'top', 
              options = list(pageLength = 5, autoWidth = TRUE ))


iris %>% DT::datatable(extensions = 'Buttons', 
               options = list(dom = 'Blfrtip', 
                              buttons = c('copy', 'csv', 'excel', 'pdf', 'print'), 
                              pageLength = 5, autoWidth = TRUE ))


#- pkg reactable: un ejemplo ----------------------------------------------------------
reactable::reactable(iris)


#- pkg rpivotTable: un ejemplo ----------------------------------------------------------

library(rpivotTable) #- remotes::install_github(c("ramnathv/htmlwidgets", "smartinsightsfromdata/rpivotTable"))
rpivotTable(df, rows = "Gender", cols = c("Country"), width = "100%", height = "400px")


#- tablas para modelos ---------------------------------------------------------
urla <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/PIAAC_data_small.csv"
df <- read_csv(urla)


#- estimammos un modelo lineal
my_model <- lm(Wage_hour ~ Numeracy_score + Gender , data = df)
my_model

summary(my_model)


#- pkg stargazer ---------------------------------------------------------------
stargazer::stargazer(my_model, type = "html")
stargazer::stargazer(my_model, type = "text")


#- creo una variable dicotomica (para estimar un Logit)
df <- df %>% mutate(Numeracy_score_b = ifelse(Numeracy_score > mean(Numeracy_score, na.rm = TRUE), 1, 0)) #- binary variable for logit model

#- estimammos varios modelos y los almacenamos en una lista
my_models <- list()
my_models[['W:  OLS 1']]   <- lm( Wage_hour         ~ Numeracy_score + Gender , df)
my_models[['Nu: OLS 2']]   <- lm( Numeracy_score    ~ Education + Gender , df)
my_models[['Nu: Logit 1']] <- glm( Numeracy_score_b ~ Education + Gender , df, family = binomial())


stargazer::stargazer(my_models, type = "html", title = "Results", align = TRUE)
stargazer::stargazer(my_models, type = "text", title = "Results", align = TRUE)


#- pkg modelsummary ------------------------------------------------------------
library(modelsummary) #- remotes::install_github('vincentarelbundock/modelsummary')

mm <- modelsummary::msummary(my_models, title = "Resultados de estimación")
mm


#- pkg gtsummary ---------------------------------------------------------------
iris %>% gtsummary::tbl_summary()

gtsummary::tbl_regression(my_model)


#- pkg sjPlot ------------------------------------------------------------------

sjPlot::tab_model(my_model)

sjPlot::plot_model(my_model)

#- más pkgs para tablas descriptivas -------------------------------------------

#- pkg stats 
my_table <- stats::xtabs(~ Education + Country + Gender, data = df)
stats::ftable(my_table)

#- pkg janitor
df %>% janitor::tabyl(Education, Country, Gender)


