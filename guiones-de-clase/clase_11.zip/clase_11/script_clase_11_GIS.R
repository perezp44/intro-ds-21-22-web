#- script para seguir el tutorial_09 (GIS en R)
#- cargando pkgs 
options(scipen = 999) #- para quitar la notación científica
pacman::p_load(knitr, here, tidyverse, patchwork, ggrepel)
pacman::p_load(sf, rnaturalearth, rnaturalearthdata, ggspatial, mapview, leafem, leaflet)
library(pjpv.datos.01)
pjpv.datos.01::ine
#- cargamos datos --------------------------------------------------------------
#CCAA <- rio::import("https://github.com/perezp44/archivos_download.2/raw/main/CCAA.rds")

load(here::here("datos", "geometrias_BigData_2021.RData"))

#- son df's PERO son spatial df's
class(CCAA)
#- tienen información geográfica (generalmente en la columna "geometry")
names(CCAA)
#- la columna "geometry" es sticky y es pesada, cuesta visualizarla
zz <- CCAA %>% sf::st_drop_geometry()

#- podemos hacer mapas con ggplot: con geom_sf()
p1 <- ggplot(CCAA,  aes(fill = ine_ccaa)) + 
          geom_sf() +
          scale_fill_viridis_d(guide = "none") +
          labs(title = "Coord. geográficas")

p1

p2 <- ggplot(CCAA, aes(fill = ine_ccaa) ) + 
           geom_sf() + coord_sf(crs = 2154, datum = sf::st_crs(2154)) +
           scale_fill_viridis_d(guide = "none") +
           labs(title = "Lambert 93")

p1 + p2


#- elegimos 4 CC.AA
zz_prov_chosen <- c("Andalucía", "Galicia", "Aragón", "Canarias", "Illes Balears")

zz_prov_1 <- Provincias %>% filter(ine_ccaa.n %in% zz_prov_chosen)
zz_prov_2 <- Provincias %>% filter(!(ine_ccaa.n %in% zz_prov_chosen))

p1 <- ggplot(zz_prov_1, aes(fill = ine_prov) ) + 
         geom_sf()  +
         scale_fill_viridis_d(guide = "none") +
         labs(title = "Coord. geográficas")

p2 <- ggplot(zz_prov_2, aes(fill = ine_prov) ) + 
         geom_sf()  +
         scale_fill_viridis_d(guide = "none") +
         labs(title = "Coord. geográficas")

p1 + p2 



#- creamos las geometrías de las CC.AA por agrupación de las geometrías provinciales
CCAA_2 <- Provincias %>% group_by(ine_ccaa, ine_ccaa.n) %>% summarize()

p1 <- ggplot(Provincias, aes(fill = ine_prov) ) + 
         geom_sf()  +
         scale_fill_viridis_d(guide = "none") +
         labs(title = "Coord. geográficas")


p2 <- ggplot(CCAA_2, aes(fill = ine_ccaa) ) + 
         geom_sf()  +
         scale_fill_discrete(guide = "none") +
         labs(title = "Coord. geográficas")

p1 + p2 



#- borramos lo q no nos hace falta ---------------------------------------------
rm(p1, p2, zz_prov_chosen, zz_prov_1, zz_prov_2, CCAA_2, zz)


#- theme un poco más adecuado para mapas ---------------------------------------
theme_set(theme_bw())  
theme_set(cowplot::theme_map())



#- antes usaba las world geometies del paquete rnaturalearth, pero ... 
world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")

#- pero ahora prefiero las geometrías del pkg tmap
library(tmap)
data(World) #- hacemos accesibles las geometrías de tmap


world <- World ; rm(World)

class(world) #- es un sf, pero tb es un data.frame
names(world) #- fijate que la ultima columna se llama geometry y almacena los datos espaciales


#- 3 formas equivalentes de usar geom_sf() (ya lo sabemos)
ggplot(data = world) + geom_sf()
ggplot(data = world, aes(geometry = geometry)) + geom_sf()
ggplot() + geom_sf(data = world, aes(geometry = geometry))



#- mejoramos un poco el mapa
ggplot(data = world) + 
  geom_sf(color = "black", fill = "lightgreen", lwd = 0.2)


#-
p <- ggplot(data = world) + geom_sf() +
       labs(title = "Gráfico 1: Mapa del mundo",
            caption = "Datos provenientes de tmap")
p


#- podemos jugar con las escalas de color
p + geom_sf(aes(fill = pop_est))
p + geom_sf(aes(fill = pop_est)) + scale_fill_distiller()
p + geom_sf(aes(fill = pop_est)) + scale_fill_viridis_c(option = "plasma")




#- proyecciones  ----
#- world2 <- st_transform(world, "+proj=laea +y_0=0 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs")
p + coord_sf(crs = "+proj=laea +y_0=00 +lon_0=155 +lat_0=-90 +ellps=WGS84 +no_defs") + 
     labs(subtitle = "Lambert Azimuthal Equal Area projection")

#- se pueden usar distintos sistemas para las proyecciones
p + coord_sf(crs = "+proj=laea +lat_0=52 +lon_0=10 +x_0=4321000 +y_0=3210000 +ellps=GRS80 +units=m +no_defs ")  #- usamos PROJ string

p + coord_sf(crs = st_crs(3035))  + #- usamos SRID identifier
  labs(subtitle = "(European-centric ETRS89 \nLambert Azimuthal Equal-Area projection)")

p + coord_sf(crs = "+init=epsg:3035")  #- usamos EPSG code (mejor no usarlo xq GDAL ha deprecated esta sintaxis)



#- hagamos zoom en Spain
p_esp <- p + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)
p_esp


#- elementos geográficos
p_esp + 
 ggspatial::annotation_scale(location = "bl", width_hint = 0.5) +
 ggspatial::annotation_north_arrow(location = "bl", which_north = "true", 
                                   pad_x = unit(0.75, "in"), pad_y = unit(0.5, "in"),
                                   style = north_arrow_fancy_orienteering)


#- puntos. Centroides
world_points <- st_centroid(world, of_largest_polygon = TRUE)    #- sustituye la geometry por el centroide
names(world_points)

p_points <- ggplot(data = world_points) + geom_sf(aes(color = name)) +
  labs(title = "Gráfico 1: Mapa del mundo (centroides)",
       caption = "Datos provenientes de tmap")

p_points + theme(legend.position = "none")

rm(p_points)
  
#- truqillo: ahora el centroide pasa a estar en 2 columnas, llamadas X e Y, donde figuran la longitud y latitud del centroide
world_points <- cbind(world, st_coordinates(st_centroid(world$geometry, of_largest_polygon = TRUE)))
names(world_points)


#- recordad: para poder ver los sf's: quitar la geometría
names(world_points)
zz <- world_points %>% select(name, iso_a3,  X, Y) %>%  
      st_set_geometry(NULL)  #- por si quiero ver mejor los datos del df


#-
p_esp + 
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
  annotate(geom = "text", x = 5.5, y = 38, 
           label = "Mar Mediterráneo", fontface = "italic", color = "grey22", size = 4)


#-
p <- p + 
  geom_sf(fill = "antiquewhite") +
  geom_text(data = world_points, 
            aes(x = X, y = Y, label = name), 
                color = "darkblue", fontface = "bold", 
                check_overlap = TRUE, size = 2) +
  annotation_north_arrow(location = "bl", which_north = "true",
                         pad_x = unit(0.75, "in"), 
                         pad_y = unit(0.5, "in"),
                         style = north_arrow_fancy_orienteering) +
  #theme(panel.grid.major = element_line(color = gray(.5), linetype = "dashed", size = 0.5)) +
  theme(panel.grid.major = element_blank()) +
  theme(panel.background = element_rect(fill = "aliceblue"))
p


#-
p + coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE) +
    ggspatial::annotation_scale(location = "bl", width_hint = 0.5)


#-
## ggsave("./pruebas/map.pdf")
## ggsave("./pruebas/map_web.png", width = 6, height = 6, dpi = "screen")


#-
pueblos <- data.frame(
               nombre = c("Pancrudo", "Valencia"), 
               longitude = c(-1.028781, -0.3756572),
               latitude = c(40.76175, 39.47534) )     
pueblos


#-
p_esp + 
  geom_point(data = pueblos, 
             aes(x = longitude, y = latitude), 
             size = 2, color = "darkred") +
  geom_text(data = pueblos, 
            aes(x = longitude, y = latitude, label = nombre), 
            color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5)


#-
pueblos_sf <- st_as_sf(pueblos, 
                       coords = c("longitude", "latitude"), 
                       crs = 4326,  #- EPSG:4326 Coordenadas Geográficas WGS84
                       agr = "constant")


#-
p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred")


#- otra vez hacemos zoom
p_esp + geom_sf(data = pueblos_sf, size = 2, color = "darkred") + 
        coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)


#- capa con las CC.AA y hacemos zoom
zz_CCAA <- CCAA %>% st_set_geometry(NULL)
head(zz_CCAA)

p + geom_sf(data = CCAA, fill = NA) + 
      coord_sf(xlim = c(-15.00, 15.00), ylim = c(21, 47.44), expand = TRUE)


#- número de municipios de las provincias de Andalucía (lo calculamos) ---------
INE_padron_muni_96_20 <- pjpv.datos.01::pob_muni_1996_2020

pob_andalucia <- INE_padron_muni_96_20 %>% 
                 filter(year == 2020) %>% 
                 filter(ine_ccaa.n == "Andalucía") %>%
                 group_by(ine_prov.n) %>% mutate(n_pueblos = n_distinct(ine_muni.n)) %>%
                 mutate(pob_prov = sum(pob_total, na.rm = TRUE)) %>% ungroup() %>%
                 mutate(pob_media_pueblos = pob_prov/n_pueblos) %>% 
                 select(ine_prov.n, ine_prov, pob_media_pueblos, pob_prov, n_pueblos) %>%
                 distinct() %>% ungroup()


#- vemos q hay en Provincias
zz_Provincias <- Provincias %>% st_set_geometry(NULL)
head(zz_Provincias)

#- fusionamos 2 df's, uno con información geográfica ---------------------------
geo_pob_andalucia <- left_join(pob_andalucia, Provincias, by = c("ine_prov" = "ine_prov"))
geo_pob_andalucia <- left_join(pob_andalucia, Provincias)
names(geo_pob_andalucia)

#-
p + geom_sf(data = CCAA, fill = NA) +
    geom_sf(data = geo_pob_andalucia, aes(geometry = geometry, fill = n_pueblos)) +
    scale_fill_viridis_c(alpha = .4) +
    geom_sf(data = pueblos_sf, size = 2, color = "darkred") +
    coord_sf(xlim = c(-15.00, 25.00), ylim = c(21, 57.44), expand = TRUE)


#- 3 pueblos  elijo "al azar" --------------------------------------------------
pueblos_3 <- IGN_nomencla_muni %>% 
             filter(NOMBRE_ACTUAL %in% c("Pancrudo", "Alburquerque", "Polentinos")) %>% 
             select(NOMBRE_ACTUAL, PROVINCIA, LONGITUD_ETRS89, LATITUD_ETRS89) %>%
             st_as_sf(coords = c("LONGITUD_ETRS89", "LATITUD_ETRS89"), crs = 4326, agr = "constant", remove = FALSE)


#-
p_esp <- p + geom_sf(data = CCAA, fill = NA) +
         geom_sf(data = geo_pob_andalucia, aes(geometry = geometry, fill = n_pueblos)) +
         scale_fill_viridis_c(alpha = .4) +
         geom_sf(data = pueblos_3, size = 2, color = "darkred") +
         ggrepel::geom_label_repel(data = pueblos_3, aes(x = LONGITUD_ETRS89, y = LATITUD_ETRS89, label = NOMBRE_ACTUAL)) +
         coord_sf(xlim = c(-10.00, 7.00), ylim = c(35, 45), expand = TRUE)
p_esp


#- Canarias (traemos a Canarias cerca de la peninsula) -------------------------
canarias <- Provincias %>% filter(ine_prov %in% c(35,38))
peninsula <- Provincias %>% filter( !(ine_prov %in% c(35, 38)) )
my_shift <- st_bbox(peninsula)[c(1,2)]- (st_bbox(canarias)[c(1,2)]) + c(-2.4, -1.1)
canarias$geometry <- canarias$geometry + my_shift
st_crs(canarias)  <- st_crs(peninsula)
peninsula_y_canarias <- rbind(peninsula, canarias)

p1 <- ggplot() + geom_sf(data = peninsula_y_canarias)
p2 <- ggplot() + geom_sf(data = peninsula) + geom_sf(data = canarias, fill = "purple") 
#coord_sf(xlim = c(-12.00, 4.00), ylim = c(33, 44), expand = TRUE)

p1 + p2 


#- 
ggplot() + geom_sf(data = peninsula) +
           geom_sf(data = canarias) +
           coord_sf(xlim = c(-12.00, 4.00), ylim = c(33, 44), expand = TRUE)


#
p_esp + geom_sf(data = canarias, fill = "red") +
         coord_sf(xlim = c(-12.00, 5.00), ylim = c(30, 44), expand = TRUE)


#- rios españoles (traemos las shapes) -----------------------------------------
zz_rios <- rios_espanya %>% st_set_geometry(NULL)
names(rios_espanya)


#- 4 rios seleccionamos "al azar" --------------------
#- no hace falta pero
cod_rios_guenos <- c(913757, 913687, 913685, 913619)
nombre_rios_guenos <- c("Pancrudo", "Jiloca", "Jalón", "Ebro")

rios_guenos <- rios_espanya %>% filter(Cod_Uni %in% cod_rios_guenos)


#-
ggplot(data = peninsula) + geom_sf() +
    geom_sf(data = rios_guenos, color = "lightblue", lwd = 1.3) +
    labs(subtitle = "Mapa de España con 4 ríos Güenos", color = "")


#-
ggplot(data = peninsula) + geom_sf() +
    geom_sf(data = rios_guenos, color = "lightblue", lwd = 1.3) +
    geom_point(data = pueblos, aes(x = longitude, y = latitude), size = 2, color = "darkred") +
    geom_text(data = pueblos, aes(x = longitude, y = latitude, label = nombre), color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) + 
    labs(subtitle = "Mapa de España con 4 ríos Güenos", color = "")


#- inset plot ---------------------
names(world)
gworld <- ggplot(data = world) +
  geom_sf(aes(fill = income_grp)) +
  # geom_sf(aes(fill = region_wb)) +
  geom_rect(xmin = -15, xmax = 25.00, ymin = 21, 
            ymax = 57.44, fill = NA, colour = "black", size = 1.5) +
  theme(panel.background = element_rect(fill = "azure")) +
  labs(subtitle = "Mapa del mundo") +
  scale_fill_discrete(guide = "none")

gworld


#--
g_europe <- ggplot(data = world) +
    geom_sf() +
    geom_sf(data = CCAA, fill = NA) +
    geom_sf(data = geo_pob_andalucia, aes(geometry = geometry, fill = n_pueblos)) +
    geom_sf(data = pueblos_3, size = 2, color = "darkred") +
    geom_label_repel(data = pueblos_3, aes(x = LONGITUD_ETRS89, y = LATITUD_ETRS89, label = NOMBRE_ACTUAL)) +
    coord_sf(xlim = c(-15.00, 25.00), ylim = c(21, 57.44), expand = TRUE) +
    theme(panel.background = element_rect(fill = "azure")) +
    labs(subtitle = "Mapa de Europa Occidental") +
    scale_fill_continuous(guide = "none")
g_europe


#
library(patchwork)
g_europe + patchwork::inset_element(gworld, 0.75, 0.75, 1.022, 1.022, align_to = "plot")

#- mapview ----------------------
mapview::mapview(pueblos_sf)
mapview::mapview(rios_guenos)


#
## INE_padron_muni_96_20 <- pjpv.datos.01::pob_muni_1996_2020
info_CCAAs <- INE_padron_muni_96_20 %>%
              filter(year == 2017) %>%
              #filter(poblacion == "Total") %>%
              group_by(ine_ccaa.n) %>%
              mutate(n_prov = n_distinct(ine_prov)) %>%
              mutate(n_pueblos = n_distinct(ine_muni)) %>%
              mutate(pob_CCAA = sum(pob_total, na.rm = TRUE)) %>% ungroup() %>%
              select(ine_ccaa, ine_ccaa.n, n_prov, n_pueblos, pob_CCAA) %>%
              distinct() %>% ungroup()



 CCAA_con_info <- left_join(CCAA, info_CCAAs)



mapview::mapview(CCAA_con_info,
                 zcol = c("ine_ccaa.n", "n_prov", "n_pueblos", "pob_CCAA"),
                 #color = "tomato", col.regions = "purple", lwd = 3,
                 cex = "n_pueblos")



#-
mapview(list(CCAA_con_info, pueblos_sf), layer.name = c("CC.AA", "2 municipios chachis"))



#- podemos dibujar
library(mapedit) #-install.packages("mapedit")

my_map <- mapview(pueblos_sf)
drawFeatures(my_map, editor = "leafpm")   #- good

#- para guardar los dibujitos
mys_dibujitos <- editMap(mapview(pueblos_sf))
mapview(mys_dibujitos$finished)


#- leaflet ---------------------------------------------------------------------
library(leaflet)
leaflet() %>% addTiles()%>% leafem::addMouseCoordinates()


#-
m <- leaflet() %>%
  addTiles() %>% 
  setView(lng = -1.0287810, lat = 40.76175, zoom = 6) %>% 
  addMarkers(lng = -1.0287810, lat = 40.76175, popup = "Pancrudo") %>% 
  addPopups(lng = -0.3756572, lat = 39.47534, popup = "Valencia")
m


#- 
lplot <- leaflet() %>%
         addTiles() %>% # Add default OpenStreetMap map tiles
          addCircleMarkers(data = pueblos_sf)
         #leafem::addHomeButton(ext = extent(breweries91), layer.name = "pueblos")


#-
leaflet(data = CCAA) %>% addTiles() %>%
   addPolygons(fillColor = topo.colors(18, alpha = NULL), stroke = FALSE)



#- podemos guardar el leaflet
htmltools::save_html(lplot, "./pruebas/leaflet.html")


#- calculamos areas
Provicias_5 <- Provincias %>% 
               mutate(area = st_area(.)) %>% 
               mutate(areakm2 = units::set_units(area, km^2)) %>% 
               arrange(desc(areakm2)) %>% 
               slice(1:5)
ggplot() + geom_sf(data = Provincias) + geom_sf(data = Provicias_5, fill = "purple")


#- calculamos el centroide
Prov_5_centroides <- st_centroid(Provicias_5) 
Prov_5_centroides <-  cbind(Prov_5_centroides, st_coordinates(st_centroid(Prov_5_centroides$geometry)))

ggplot() + geom_sf(data = Provincias) + 
           geom_sf(data = Provicias_5, fill = "purple") +
           geom_text(data = Prov_5_centroides, 
                     aes(x = X, y = Y, label = ine_prov.n),
                     color = "darkblue", fontface = "bold", check_overlap = TRUE, size = 2.5) +
          labs(title = "Las 5 provincias españolas más extensas", x = "", y = "") 


#-
## Prov_centroides <- st_centroid(Provincias)
## Prov_centroides_XY <- cbind(Prov_centroides, st_coordinates(st_centroid(Prov_centroides$geometry)))
## distancias <- st_distance(Prov_centroides_XY, by_element = FALSE) #- devuelve una matriz


#-
municipios <- IGN_nomencla_muni
municipios <- municipios %>% select(COD_INE, PROVINCIA, NOMBRE_ACTUAL, LONGITUD_ETRS89, LATITUD_ETRS89)


#
municipios_sf <- st_as_sf(municipios, coords = c("LONGITUD_ETRS89", "LATITUD_ETRS89"), crs = st_crs(4258))
names(municipios_sf)

#-
pancrudo_sf <- municipios_sf %>% filter(NOMBRE_ACTUAL == "Pancrudo")
g1 <- st_geometry(municipios_sf)
g1_pancrudo <- st_geometry(pancrudo_sf) #- dejo solo la geometria

#- distancias_a_Pancrudo <- mapply(st_distance, g1, g1_pancrudo) %>% as.vector) #- con R-base
distancias_a_Pancrudo <- map2(g1, g1_pancrudo, st_distance) %>% as_vector()         #- con purrr
distancias_a_Pancrudo <- as.data.frame(distancias_a_Pancrudo)
df_con_distancias_a_Pancrudo <- bind_cols(municipios_sf, distancias_a_Pancrudo) %>% 
                                mutate(Kms = distancias_a_Pancrudo * 100) %>% 
                                arrange(Kms)


#-
muni_xx <- municipios_2020 %>% st_set_geometry(NULL)
muni    <- municipios_2020


#
#zz <- muni_xx %>% group_by(ine_ccaa, ine_ccaa.n) %>% count()
muni_borrar <- c("Illes Balears", "Canarias")
muni <- muni %>% filter(!(ine_ccaa.n %in% muni_borrar))




#-
rio_ebro_4_xx <- rio_ebro_4 %>% st_set_geometry(NULL)
rio_ebro_4_x <- rio_ebro_4 %>% select(Nom_Rio, Long_Rio_m, geometry) %>% group_by(Nom_Rio) %>% summarize()


#
pueblos  <- data.frame(nombre = c("Pancrudo", "Valencia"), longitude = c(-1.028781, -0.3756572), latitude = c(40.76175, 39.47534) ) #- ETRS89


#
theme_set(cowplot::theme_map())
p <- ggplot(muni) + 
     geom_sf(color = "grey", fill = "antiquewhite", lwd = 0.11) +
     geom_sf(data = rio_ebro_4_x, color = "lightblue", lwd = 1.6) +
     geom_point(data = pueblos, aes(x = longitude, y = latitude), size = 3, color = "darkred") +
     geom_text(data  = pueblos, aes(x = longitude, y = latitude, label = nombre), color = "darkred", fontface = "bold", check_overlap = TRUE, size = 2.5) +
     labs(title = "R-Mapa con 4 ríos güenos",
          caption = "Datos provenientes del paquete LAU2boundaries4spain") +  
          theme(panel.background = element_rect(fill = "aliceblue"))
p


#-
muni_a <- muni %>% st_transform(crs = st_crs(rio_ebro_4_x))
zz_a <- st_intersects(muni_a, rio_ebro_4_x, sparse = FALSE, prepared = TRUE)


#-
muni_ebro <- muni_a[zz_a, ]


# muni_ebro2 <- cbind(muni_a, zz_a[1,])
# muni_ebro2 <- muni_ebro2 %>% filter(zz_a == TRUE)  
  


#-
p + geom_sf(data = muni_ebro,  fill = "tomato", color = "grey") +
    geom_sf(data = rio_ebro_4_x, color = "blue", lwd = 0.15)

