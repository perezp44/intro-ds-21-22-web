#- script para generar a bunch of parametrised reports
#- para ello tenemos que utilizar la función: rmarkdown::render()

library(tidyverse)

#- informe para toda la Comunitat
rmarkdown::render(
  input = here::here("ej_parametrised-Rmds", "my_report.Rmd"), 
  output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", "informe_Comunitat.html")
  )


#- vamos a crear un informe usando los parámetros (Valencia en 2017) ---------------------------------
rmarkdown::render(
  input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
  output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", "Valencia-en-2017.html"),
  params = list(municipio = "Valencia", periodo = 2017)
)



#- vamos a crear un conjunto de informes
#- haremos el informe para un conjunto de municipios (pero para un solo periodo, p.ej: año 2010)
my_municipios <- c("Valencia", "Alzira")


#- 
for (ii in 1:length(my_municipios)) {
  my_MUNICIPIO <- my_municipios[ii]
  my_HEADER <- glue::glue("Informe para ", {my_MUNICIPIO} , " (Año 2010)")
  my_HEADER <- paste("Informe para ", my_MUNICIPIO , "(Año 2010)")
    #---
  rmarkdown::render(
    input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
    output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", my_municipios[ii]),
    params = list(municipio = my_MUNICIPIO, periodo = 2010) )
  }
          
        

#- ahora lo hacemos tb para varios periodos -------------------------------
my_municipios <- c("Valencia", "Alzira")
my_anyitos <- c(2010, 2017)


for (ii in 1:length(my_municipios)) {
  my_MUN <- my_municipios[ii]
  
    for (jj in 1:length(my_anyitos)) {
      my_ANY <- my_anyitos[jj]
      my_titulo_informe <- glue::glue("Informe para ", {my_MUN} , " (Año ", {my_ANY}, ")")
      my_titulo_informe <- paste0(my_MUN, "-", my_ANY)
      #------
      
      rmarkdown::render(
            input = here::here("ej_parametrised-Rmds", "my_parametrised_report.Rmd"), 
            params = list(municipio = my_MUN, periodo = my_ANY),
            output_file = here::here("ej_parametrised-Rmds", "informes-automaticos", my_titulo_informe) ) 
  }
}
          
          

