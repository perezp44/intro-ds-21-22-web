#- script para clase_13: cosas de  EDA y modelos
library(tidyverse)
options(scipen = 999) #- quitar notación científica

#- cargo DATOS: df_bebes_small_2021.rds ----------------------------------------
df_small <- rio::import(here::here("datos", "df_bebes_small_2021.rds"))

#- selecciono 1000 bebes (para ir rápido)
set.seed(1234) #- for reproducibility, para q nos salgan a todos mismos rtdos
df <- df_small %>% slice_sample(n = 1000)

#- creo dicc. de los datos q voy a USAR 
df_aa <- pjpv2020.01::pjp_f_estadisticos_basicos(df)
df_bb <- pjpv2020.01::pjp_f_unique_values(df, truncate = TRUE, nn_truncate = 50)
dicc_df <- bind_cols(df_aa, df_bb)
dicc_df <- dicc_df %>% select(variable, type, nn_unique, unique_values, q_na, p_na, p_zeros, min, max, mean, sd, NN, NN_ok)


#- df's no quitar --------------------------------------------------------------
no_quitar <- c("df_small", "df", "dicc_df")
rm(list=ls()[! ls() %in% no_quitar])




#- informes completos ----------------------------------------------------------
#---------------------------------  con DataExplorer pkg
# - informe sin especificar variable objetivo
DataExplorer::create_report(df, 
                            output_dir = "pruebas",
                            output_file = "my_report_DataExplorer.html")

#--------------------------------- con dlookr package
dlookr::diagnose_paged_report(df, 
                        output_dir = "pruebas",
                        output_file = "my_report_dlookr.pdf")


#--------------------------------- con SmartEDA pkg
SmartEDA::ExpReport(df, 
                    op_dir = "pruebas",
                    op_file = "my_smarteda.html")


#--------------------------------- con summarytools pkg
summarytools::dfSummary(df)


#- nombres: manejar y arreglar -------------------------------------------------
df_copy <- df %>% dplyr::rename(fecha_parto_nueva = fecha_parto)

names(df_copy)
names(df_copy)[1] <- paste0(names(df_copy)[1], "_new") #- cambio el primer nombre
names(df_copy)[2] <- "nuevo >>> <<<<  Ñombre"    #- cambio el nombre de la segunda variable
names(df_copy)


df_copy <- janitor::clean_names(df_copy)
names(df_copy)
rm(df_copy)

#- estructura y tipos de vv. ---------------------------------------------------
str(df)            #- str() muestra la estructura interna de un objeto R
unclass(df[[1]])   #- para ver como se almacenan las fechas
as.POSIXct(df[[1]][1], format="%Y-%m-%dT%H:%M")
#- si te interesa el tema de los husos horarios este video es chulo: 
#- https://www.youtube.com/watch?v=-5wpm-gesOY



inspectdf::inspect_types(df)   #- muestra de que tipo son las variables


#- valores únicos de las vv. ---------------------------------------------------
zz <- pjpv2020.01::pjp_f_unique_values(df, truncate = TRUE, nn_truncate = 47) 

zz <- pjpv2020.01::pjp_f_valores_unicos(df)

zz <- df %>% distinct(prov_inscrip.n, parto_cesarea.f)
zz %>% gt::gt()
zz

#- estadisticos basicos de las vv. ---------------------------------------------
zz <- pjpv2020.01::pjp_f_estadisticos_basicos(df)   #- estadísticos básicos del df


zz <- summarytools::dfSummary(df) #- genera un fichero con un resumen útil y agradable de ver
summarytools::view(zz)            #- para visualizar el informe


skimr::skim(df)


#- gtsummary::tbl_summary especificar variables de agrupación y realizar algunos contrastes
df %>% select(peso_bebe, parto_nn_semanas, estudios_madre.ff, parto_cesarea.f) %>% 
  gtsummary::tbl_summary(by = "parto_cesarea.f") %>% 
  gtsummary::add_p()



#- NA's: missing values --------------------------------------------------------
DataExplorer::plot_missing(df)

naniar::gg_miss_var(df, show_pct = TRUE)        

visdat::vis_dat(df) 

visdat::vis_miss(df, cluster = TRUE) 

naniar::gg_miss_upset(df, order.by = "degree")   #- !!!!!


dlookr::plot_na_intersect(df)

#- mis calculitos ---- pasando
zz1 <- df %>% tidyr::drop_na()
zz2 <- anti_join(df, zz1)
zz3 <- df %>% filter(is.na(estudios_padre.ff) & is.na(parto_nn_semanas))
zz4 <- df %>% filter(is.na(estudios_padre.ff))
rm(list = ls(pattern = "^zz"))  #- borra los objetos cuyo nombre empiece por zz



#- manejando los NA's ----------------------------------------------------------
zz_con_NAs  <- df %>% select(where(anyNA))


naniar::gg_miss_var(df, facet = estudios_madre.ff, show_pct = TRUE) #- faceted por la variable estudios_madre.f


#- quitar filas donde hay algún NA
zz <- df %>% tidyr::drop_na()              #- con tidyr
zz <- df[complete.cases(df), ]             #- con base-R 
zz <- df %>% filter(complete.cases(.))     #- con dplyr y base-R

#- quitar filas con NA en alguna(s) vv.

zz <- df %>% tidyr::drop_na(c(peso_bebe, parto_nn_semanas))   #- quito filas con NA en peso_bebe o en SEMANAS


zz <- df %>% janitor::remove_empty(c("rows", "cols"))    #- quita variables y filas vacías

rm(list = ls(pattern = "^zz"))  #- borra los objetos cuyo nombre empiece por zz


#- vv. NUMERICAS ---------------------------------------------------------------
df_numeric <- df %>% select_if(is.numeric)      #- antigua sintaxis
df_numeric <- df %>% select(where(is.numeric))  #- nueva API


summarytools::descr(df)


DataExplorer::plot_histogram(df, ncol = 2)
DataExplorer::plot_density(df, ncol = 2)

#- correlaciones 
stats::cor(df_numeric, use = "pairwise.complete.obs") %>%  #- devuelve una matriz, no un df
      round(. , 2)


df_numeric %>% GGally::ggcorr(label = TRUE)

df_numeric %>% GGally::ggpairs()



df %>% select_if(is.numeric) %>% 
       corrr::correlate() %>% 
       #pjpv2020.01::pjp_f_decimales(nn = 2) %>%  
       gt::gt()



df %>% inspectdf::inspect_cor()



df %>% inspectdf::inspect_cor() %>% inspectdf::show_plot() #- GOOD


correlation::correlation(df_numeric)    #- remotes::install_github("easystats/correlation")


#- boxplots con separación
DataExplorer::plot_boxplot(df, by = "estudios_madre.ff")

my_vv <- names(df)[3]
my_vv <- "parto_cesarea.f"
DataExplorer::plot_boxplot(df, by = my_vv)



df %>% explore::explore(edad_madre.1, estudios_madre.ff, target = parto_cesarea.f)


df %>% select(sexo_bebe.f, edad_madre.1, peso_bebe,  estudios_madre.ff, parto_cesarea.f) %>% explore::explore_all(target = parto_cesarea.f)


#-
df %>% janitor::tabyl(estudios_madre.ff, parto_cesarea.f) %>% janitor::adorn_percentages()


#-
my_vv <- "peso_bebe"
DataExplorer::plot_scatterplot(df, by = my_vv, sampled_rows = 500L)


#- vv. "DISCRETAS" -------------------------------------------------------------
df %>% select_if(is.factor) %>% names()      #- old fashion
df %>% select(where(is.factor)) %>% names()


df %>% select_if(!(is.numeric(.))) #- NO funciona
df %>% select_if(~ !is.numeric(.)) %>% names()     #- anonymous function but select_if
df %>% select(where(~ !is.numeric(.))) %>% names() #- anonymous functions & where
df %>% select(where(purrr::negate(is.numeric)))  %>% names()   #- purrr::negate()!!!!


#
inspectdf::inspect_cat(df) %>% inspectdf::show_plot(high_cardinality = 1)  #- GOOD


#
DataExplorer::plot_bar(df, nrow = 4, ncol = 4)


#
DataExplorer::plot_bar(df, nrow = 4, ncol = 4, by = "sexo_bebe.f")


SmartEDA::ExpCatViz(df, Page = c(3,3)) #- GOOD!!


#- paquetes con shiny ----------------------------------------------------------
#- devtools::install_github("laderast/burro")
burro::explore_data(df, outcome_var = colnames(df))


explore::explore(df)
df %>% explore::explore(parto_cesarea.f)
df %>% explore::explore(edad_madre.1, estudios_madre.f, target = parto_cesarea.f)



library(ExPanDaR) #- remotes::install_github("joachim-gassen/ExPanDaR")

ExPanD(df)


#- TABLAS ----------------------------------------------------------------------
#- con summarytools
summarytools::freq(df$sexo_bebe.f, style = "rmarkdown")

summarytools::ctable(df$sexo_bebe.f, df$parto_cesarea.f)

summarytools::ctable(df$estudios_madre.ff, df$parto_normal.f, chisq = TRUE)


#- con janitor
df %>% janitor::tabyl(parto_cesarea.f) %>% gt::gt()


df %>% janitor::tabyl(parto_cesarea.f, estudios_madre.ff) %>% gt::gt()

df %>% janitor::tabyl(parto_cesarea.f, estudios_madre.ff, sexo_bebe.f)  #- xq no podemos usar gt::gt()


#- tablas de R-base
table(df$parto_cesarea.f, df$estudios_madre.ff, useNA = "always") 

my_tabla <- table(df$parto_cesarea.f, df$estudios_madre.ff) #- no la guarda como df
my_tabla

my_tabla2 <- my_tabla %>% as.data.frame() %>% 
            pivot_wider(names_from = 2, values_from = 3) 
my_tabla2 %>% gt::gt()


#- prop table
zz <- prop.table(my_tabla, 1)
zz
mosaicplot(t(zz), color = TRUE, main = "% de Cesáreas para niveles educativos de la madre")


#- CONTRATES -------------------------------------------------------------------
t.test(df$peso_bebe)
t.test(df$peso_bebe, mu = 3250)
t.test(df$peso_bebe ~ df$parto_cesarea.f)
t.test(df$peso_bebe ~ df$sexo_bebe.f)   #- significativo


#- corr
Hmisc::rcorr(as.matrix(df_numeric))


#- !!!!!!!!!!!
library(purrr)
library(broom)
df %>% group_by(estudios_madre.ff) %>% 
  summarise(t_test = list(t.test(peso_bebe))) %>% 
  mutate(tidied = map(t_test, tidy)) %>% 
  tidyr::unnest(tidied) %>% 
  ggplot(aes(estimate, estudios_madre.ff)) + geom_point() +
  geom_errorbarh(aes(xmin = conf.low, xmax = conf.high)) + 
  labs(title = "Peso del bebe para diferentes niveles educativos de la madre")


#- chi
chisq.test(df$parto_cesarea.f, df$sexo_bebe.f)
chisq.test(df$parto_cesarea.f, df$estudios_madre.ff) 

