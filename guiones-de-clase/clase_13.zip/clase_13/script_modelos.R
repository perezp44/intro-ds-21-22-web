#- script para clase_13: cosas de  EDA y modelos
library(tidyverse)
options(scipen = 999) #- quitar notación científica


#- cargo DATOS: df_bebes_small_2021.rds ----------------------------------------
df_small <- rio::import(here::here("datos", "df_bebes_small_2021.rds"))

#- selecciono 1000 bebes (para ir rápido)
set.seed(1234) #- for reproducibility, para q nos salgan a todos mismos rtdos
df <- df_small %>% slice_sample(n = 1000)

#- creo dicc. de los datos q voy a USAR 
df_aa <- pjpv2020.01::pjp_f_estadisticos_basicos(df)
df_bb <- pjpv2020.01::pjp_f_unique_values(df, truncate = TRUE, nn_truncate = 50)
dicc_df <- bind_cols(df_aa, df_bb)
dicc_df <- dicc_df %>% select(variable, type, nn_unique, unique_values, q_na, p_na, p_zeros, min, max, mean, sd, NN, NN_ok)


#- df's no quitar --------------------------------------------------------------
no_quitar <- c("df_small", "df", "dicc_df")
rm(list=ls()[! ls() %in% no_quitar])





#- MODELOS ---------------------------------------------------------------------
#- restrinjamos aún más el df
df_m <- df %>% select(peso_bebe, parto_nn_semanas, sexo_bebe.f, parto_cesarea.f, edad_madre.1, edad_padre.1, estudios_madre.ff, estudios_padre.ff)
df_m <- df_m %>% drop_na()

#- estimemos algunos modelos con df_m

mod_1 <- lm(peso_bebe ~ . , data = df_m) #- el . significa frente a todas las otras v.
summary(mod_1)

#- cual es la categoría de referencia para las dummies?
levels(df$sexo_bebe.f)
levels(df$estudios_madre.ff)

#- podemos cambiar la categoria de referencia
zz <- forcats::fct_relevel(df$sexo_bebe.f, "bebito")
levels(zz)



#- veamos un poco más q. hay en "mod_1" es una lista (luego veremos un poco más)
str(mod_1)
#listviewer::jsonedit(mod_1, mode = "view") ## Interactive option


#- mas modelos -----------------------------------------------------------------
mod_1 <- lm(peso_bebe ~ parto_nn_semanas, data = df_m)
summary(mod_1)

mod_1 <- lm(peso_bebe ~ parto_nn_semanas + sexo_bebe.f + parto_cesarea.f + edad_madre.1 , data = df_m)
summary(mod_1)

mod_1 <- lm(log(peso_bebe) ~ log(parto_nn_semanas), data = df_m)
summary(mod_1)


#- intearcciones entre los regresores (:)
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + parto_nn_semanas:edad_madre.1, data = df_m)
summary(mod_1)

#- mejor con I()
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + I(parto_nn_semanas*edad_madre.1), data = df_m)
summary(mod_1)

#- "cuidado" con *
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + parto_nn_semanas*edad_madre.1, data = df_m)
summary(mod_1)



#- 
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1 + parto_nn_semanas:edad_madre.1, data = df_m)
summary(mod_1)

#- tb hace lo mismo
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1 + I(parto_nn_semanas*edad_madre.1), data = df_m)
summary(mod_1)

#- con *
mod_1 <- lm(peso_bebe ~ parto_nn_semanas*edad_madre.1, data = df_m)
summary(mod_1)

#- again * 
mod_1 <- lm(peso_bebe ~ parto_nn_semanas*estudios_madre.ff, data = df_m)
summary(mod_1)


#- ahora quiero un término cuadrático (funciona)
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + I(parto_nn_semanas*parto_nn_semanas), data = df_m)
summary(mod_1)

#- no chuta(por qué??)
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + parto_nn_semanas*parto_nn_semanas, data = df_m)
summary(mod_1)

#- uso de poly()
mod_1 <- lm(peso_bebe ~ poly(parto_nn_semanas, degree = 3), data = df_m)
summary(mod_1)


#- veamos un poco más q hay dentro de mod_1
mod_1 <- lm(peso_bebe ~ parto_nn_semanas, data = df_m)
summary(mod_1)

(zz_betas     <- mod_1[[1]])

(zz_residuals <- mod_1[[2]])
(zz_residuals <- mod_1[["residuals"]])
(zz_residuals <- mod_1$residuals)
 
(zz_betas_1   <- mod_1[[1]])      #- [[ ]] doble corchete
(zz_betas_2 <- mod_1[1] )         #- []    corchete simple
 
rm(list = ls(pattern = "^zz"))  #- borra los objetos cuyo nombre empiece por zz

#- otra vez [, [[ y $
zz_betas_1a <- mod_1[["coefficients"]]   #- doble corchete
zz_betas_1b <- mod_1$coefficients        #- $
zz_betas_1c <- mod_1["coefficients"]     #- single corchete

rm(list = ls(pattern = "^zz"))  #- borra los objetos cuyo nombre empiece por zz

#-
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1 + sexo_bebe.f , data = df_m)
 
summary(mod_1)                   #- tabla resumen
summary(mod_1)$coefficients      #- tabla resumen con los coeficientes
coefficients(mod_1)              #- coeficientes estimados
confint(mod_1, level = 0.95)     #- Intervalos de confianza para los coeficientes
fitted(mod_1)                   #- predicciones (y-sombrero, y-hat)
residuals(mod_1)                #- vector de residuos
model.matrix(mod_1)             #- extract the model matrix
anova(mod_1)                     #- ANOVA
vcov(mod_1)                      #- matriz de var-cov para los coeficientes
influence(mod_1)                #- regression diagnostics
# diagnostic plots
layout(matrix(c(1, 2, 3, 4), 2, 2))   #- optional 4 graphs/page
plot(mod_1)                      #-
library(ggfortify)
ggplot2::autoplot(mod_1, which = 1:6, ncol = 2, colour = "steelblue")

#-
GGally::ggcoef(mod_1)


#-
df_jugar <- df_m %>% select(edad_madre.1, sexo_bebe.f, parto_nn_semanas)

GGally::ggpairs(df_jugar)


#- Predicciones con predict() --------------------------------------------------
nuevas_observaciones <- df_m %>% slice(c(3, 44, 444))

stats::predict(mod_1, newdata = nuevas_observaciones)  #- predicciones puntuales
stats::predict(mod_1, newdata = nuevas_observaciones, type = 'response', se.fit = TRUE)  #- tb errores estándar  predictions
predict(mod_1, newdata = nuevas_observaciones, interval = "confidence")  #- intervalo (para el valor esperado)
predict(mod_1, newdata = nuevas_observaciones, interval = "prediction")  #- intervalo (para valores individuales)



#- errores estándar robustos :  paquete estimatr.
#- install.packages("emmeans")
mod_1 <- lm(peso_bebe ~ parto_nn_semanas, data = df_m)
summary(mod_1)
mod_1_ee <- estimatr::lm_robust(peso_bebe ~ parto_nn_semanas, data = df_m)
summary(mod_1_ee)


#- BROOM pkg -------------------------------------------------------------------
#- 3 funciones útiles: tidy() ,  glance()  y  augment()  

#- tidy()
zz <- broom::tidy(mod_1, conf.int = TRUE)
zz %>% pjpv2020.01::pjp_f_decimales(nn = 2)  %>% gt::gt()


#- glance()
broom::glance(mod_1)
broom::glance(mod_1) %>% select(adj.r.squared, AIC)


#- augment(): añade residuos, predicciones etc ....
zz <- broom::augment(mod_1)


#- un ejemplo: seleccionar coeficientes significativos
mod_1 %>% broom::tidy() %>% filter(p.value < 0.05)


#- recordamos ggplot2
ggplot(data = df_m, 
       mapping = aes(x = edad_madre.1,
                     y = peso_bebe,  color = estudios_madre.ff)) +
      geom_point(alpha = 0.1) +  
      geom_smooth(method = "lm")

ggplot(data = df_m, 
       mapping = aes(x = edad_madre.1, 
                     y = peso_bebe,  color = sexo_bebe.f)) +
      geom_point(alpha = 0.1) +  
      geom_smooth(method = "lm")

ggplot(data = df_m, 
       mapping = aes(x = edad_madre.1, 
                     y = peso_bebe,  color = sexo_bebe.f)) +
      geom_point(alpha = 0.1) +  
      geom_smooth()


#- ejmeplo de uso de broom
mod_1 <- lm(peso_bebe ~ edad_madre.1 + sexo_bebe.f , data = df_m)
summary(mod_1)

td_mod_1 <- mod_1 %>% broom::augment(data = df_m) 

td_mod_1 %>% 
  ggplot(mapping = aes(x = edad_madre.1, 
                       y = peso_bebe, color = sexo_bebe.f)) +
                geom_point(alpha = 0.1) +
                geom_line(aes(y = .fitted, group = sexo_bebe.f))


#
td_mod_1 %>% 
  ggplot(mapping = aes(x = edad_madre.1, 
                       y = .fitted,  color = sexo_bebe.f)) +
                geom_line(aes(group = sexo_bebe.f)) 


#- !!!!
library(broom)
df_m %>% group_by(sexo_bebe.f) %>% do(tidy(lm(peso_bebe ~ parto_nn_semanas, .)))


#- graficando intervalos para los coeficientes
td_mod_1 <- tidy(mod_1, conf.int = TRUE)
ggplot(td_mod_1, aes(estimate, term, color = term)) +
    geom_point() +
    geom_errorbarh(aes(xmin = conf.low, xmax = conf.high)) +
    geom_vline(xintercept = 0)


#- 
mod_1 %>% augment(data = df_m) %>%
 ggplot(mapping = aes(x = parto_nn_semanas, 
                      y = .fitted, color = sexo_bebe.f)) +
   geom_point(mapping = aes(y = peso_bebe), alpha = 0.1) +
   geom_line()


#-
mod_1 %>% augment(data = df_m) %>%
 ggplot(mapping = aes(x = parto_nn_semanas, 
                      y = .fitted, color = sexo_bebe.f)) +
   geom_point(mapping = aes(y = peso_bebe), alpha = 0.1) +
   geom_line() +
  facet_wrap(vars(estudios_madre.ff))


#
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1,  data = df_m)
mod_2 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1 + I(parto_nn_semanas*edad_madre.1), data = df_m)
summary(mod_1)
anova(mod_1, mod_2)


#-
AIC(mod_1, mod_2)


#
lmtest::lrtest(mod_1, mod_2)    


#- ordenamos modelos en f. del AIC (!!!!)
modelos <- list(
  mod_1 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1,  data = df_m),
  mod_2 <- lm(peso_bebe ~ parto_nn_semanas + edad_madre.1 + I(parto_nn_semanas*edad_madre.1), data = df_m)  )

modelos_ordered_AIC <- purrr::map_df(modelos, broom::glance, .id = "model") %>% arrange(AIC)

modelos_ordered_AIC %>% gt::gt()


#- una tabla con broom (!!!!)
 
my_kable <- function(df){gt::gt(mutate_if(df, is.numeric, round, 2))}

broom::tidy(mod_1) %>% my_kable


#- el paquete modelr
zz <- df_m %>% modelr::gather_predictions(mod_1, mod_2)

zz1 <- pivot_wider(zz, names_from = model, values_from = pred)


#- modelos GLM -----------------------------------------------------------------
mod_logit <- glm(parto_cesarea.f ~ peso_bebe + parto_nn_semanas + edad_madre.1 + estudios_madre.ff, family = binomial(link = "logit"), data = df_m)

summary(mod_logit)


#- calculo de efectos marginales
mod_1_AME <- mod_logit %>% margins::margins() %>% summary() 
mod_1_AME

#- paquete margins para emular tablas de Stata
mod_logit %>% margins::margins(at = list(parto_nn_semanas = c(25, 35), estudios_madre.ff = c("Primarios", "Medios", "Universidad")),  variables = "edad_madre.1" )


#
margins::cplot(mod_logit, x = "estudios_madre.ff", dx = "edad_madre.1", what = "effect", drop = TRUE)

margins::cplot(mod_logit, x = "estudios_madre.ff", dx = "edad_madre.1")


#- Tablas para modelos ---------------------------------------------------------

#- con sjPlot package
m1 <- lm(peso_bebe ~ 
           parto_nn_semanas + sexo_bebe.f + edad_madre.1 + edad_padre.1, 
         data = df)
m2 <- lm(peso_bebe ~ 
           parto_nn_semanas + sexo_bebe.f + edad_madre.1 + edad_padre.1 + estudios_madre.ff + estudios_padre.ff, 
         data = df)
sjPlot::tab_model(m1)
sjPlot::plot_model(m1, sort.est = TRUE)
sjPlot::tab_model(m1, m2)


#- con stargazer
mod_1 <- lm(peso_bebe ~ parto_nn_semanas + sexo_bebe.f , data = df_m)
stargazer::stargazer(mod_1, type = "html") #- html
stargazer::stargazer(mod_1, type = "text") #- html


#- con modelsummary
#remotes::install_github('vincentarelbundock/modelsummary')
library(modelsummary)

mys_modelitos <- list()
mys_modelitos[["peso_bebe:  OLS 1"]]    <-  lm(peso_bebe    ~ parto_nn_semanas + sexo_bebe.f,            df_m)
mys_modelitos[["peso_bebe:  OLS 2"]]    <-  lm(peso_bebe    ~ parto_nn_semanas + sexo_bebe.f + edad_madre.1 , df_m)
mys_modelitos[["CESAREA: Logit 1"]]  <- glm(parto_cesarea.f ~ parto_nn_semanas + sexo_bebe.f , data = df_m, family = binomial(link = "logit"))

mm <- msummary(mys_modelitos, title = "Resultados de estimación")
mm


#
## library(report) #- devtools::install_github("neuropsychology/report")
## my_model <- lm(peso_bebe ~ parto_nn_semanas + sexo_bebe.f, df_m)
## rr <- report(my_model, target = 1)
## rr


#
## report::as.report(rr)


#
## library(equatiomatic)  #- remotes::install_github("datalorax/equatiomatic")
## extract_eq(mod_1)
## extract_eq(mod_1, use_coefs = TRUE)

