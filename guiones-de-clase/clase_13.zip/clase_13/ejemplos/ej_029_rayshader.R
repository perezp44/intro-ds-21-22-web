#- ejemplo rayshader: Transform ggplot2 objects into 3D — plot_gg"   https://www.rayshader.com/reference/plot_gg.html
#- https://www.tylermw.com/3d-ggplots-with-rayshader/
library(tidyverse)
library(rayshader)


p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Species)) + geom_point() 
p <- ggplot(iris, aes(Sepal.Length, Petal.Length, color = Petal.Width)) + geom_point() 

rayshader::plot_gg(p, multicore = TRUE, width = 5, height = 5, scale = 250) 


#- otro gráfico
p <-  ggplot(diamonds, aes(x, depth)) +
  stat_density_2d(aes(fill = stat(nlevel)), geom = "polygon", n = 100, bins = 10, contour = TRUE) +
  facet_wrap(vars(clarity)) +
  scale_fill_viridis_c(option = "A")

rayshader::plot_gg(p, multicore = TRUE, width = 5, height = 5, scale = 250)  


