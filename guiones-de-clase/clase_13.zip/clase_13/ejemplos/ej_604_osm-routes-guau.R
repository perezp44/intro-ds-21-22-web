#- https://bensstats.wordpress.com/2021/10/25/robservations-16-using-the-mapbox-api-with-leaflet/
#- tiene otro post muy parecido: https://bensstats.wordpress.com/2021/10/21/robservations-15-i-reverse-engineered-atlas-co-well-some-of-it/

library(tidyverse)
library(leaflet)
library(tidygeocoder)
library(osrm)  #- https://github.com/riatelab/osrm
#- OSRM is a routing service based on OpenStreetMap data. See http://project-osrm.org/ for more information. This package allows to compute routes, trips, isochrones and travel distances matrices (travel time and kilometric distance).

my_punto_inicial <- "Valencia"
my_punto_final <- "Pancrudo"

plot_route_Mapbox <- function(to, 
                            from,
                            how="car",
                            colour="black",
                            opacity=1,
                            weight=1,
                            radius=2,
                            label_text=c(to,from),
                            label_position="bottom",
                            provider=providers$CartoDB.PositronNoLabels,
                            font = "Lucida Console",
                            font_weight="bold",
                            font_size= "14px",
                            text_indent="15px",
                            saturation=0,
                            mapBoxTemplate= "//{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"){
  address_single <- tibble(singlelineaddress = c(to,from)) %>% 
    geocode(address=singlelineaddress,method = 'arcgis') %>% 
    transmute(id = singlelineaddress,
              lon=long,
              lat=lat)
  
  trip <- osrmRoute(src=address_single[1,2:3] %>% c,
                    dst=address_single[2,2:3] %>% c,
                    returnclass="sf", 
                    overview="full",
                    osrm.profile = how )
  
  m <- leaflet(trip,
             options = leafletOptions(zoomControl = FALSE,
                                      attributionControl=FALSE)) %>%
    fitBounds(lng1 = max(address_single$lon)+0.1,
              lat1 = max(address_single$lat)+0.1,
              lng2 = min(address_single$lon)-0.1,
              lat2 = min(address_single$lat)-0.1) %>%  
    addTiles(urlTemplate = mapBoxTemplate) %>% 
    addCircleMarkers(lat = address_single$lat,
                     lng = address_single$lon,
                     color = colour,
                     stroke = FALSE,
                     radius = radius,
                     fillOpacity = opacity) %>%
    addPolylines(color = colour,
                 opacity=opacity,
                 weight=weight) %>% 
    addLabelOnlyMarkers(address_single$lon,
                        address_single$lat, 
                        label =  label_text,
                        labelOptions = labelOptions(noHide = T,
                                                    direction = label_position,
                                                    textOnly = T,
                                                    style=list("font-family" = font,
                                                               "font-weight"= font_weight,
                                                               "font-size"=font_size,
                                                               "text-indent"=text_indent))) 
  
  m
}

viz <- plot_route_Mapbox(my_punto_inicial,
                         my_punto_final,
                        how="car",
                        font="Courier",
                        label_position="right",
                        weight=1.5,
                        mapBoxTemplate ="https://api.mapbox.com/styles/v1/benyamindsmith/ckv64zmgy1awy14ofg33zmszz/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoiYmVueWFtaW5kc21pdGgiLCJhIjoiY2tiMDR3NXpzMDU3bjJ1cXVqNmx3ODhudyJ9.KffbwvHgcIn1GL1DV4uUBQ")

viz


#- hacerlo un visual  ----------------------------------------------------------
#- en otro post con la ff. casi igual


library(tidyverse)
library(leaflet)
library(tidygeocoder)
library(osrm)



plot_route <- function(to, 
                     from,
                     how="car",
                     colour="black",
                     opacity=1,
                     weight=1,
                     radius=2,
                     label_text=c(to,from),
                     label_position="bottom",
                     provider=providers$CartoDB.PositronNoLabels,
                     font = "Lucida Console",
                     font_weight="bold",
                     font_size= "14px",
                     text_indent="15px"){
  address_single <- tibble(singlelineaddress = c(to,from)) %>% 
    geocode(address=singlelineaddress,method = 'arcgis') %>% 
    transmute(id = singlelineaddress,
              lon=long,
              lat=lat)
  
  trip <- osrmRoute(src=address_single[1,2:3] %>% c,
                    dst=address_single[2,2:3] %>% c,
                    returnclass="sf", 
                    overview="full",
                    osrm.profile = how )
  
  m<-leaflet(trip,
             options = leafletOptions(zoomControl = FALSE,
                                      attributionControl=FALSE)) %>%
    fitBounds(lng1 = max(address_single$lon)+0.1,
              lat1 = max(address_single$lat)+0.1,
              lng2 = min(address_single$lon)-0.1,
              lat2 = min(address_single$lat)-0.1) %>%  
    addTiles() %>% 
    addProviderTiles(provider = provider) %>% 
    addCircleMarkers(lat = address_single$lat,
                     lng = address_single$lon,
                     color = colour,
                     stroke = FALSE,
                     radius = radius,
                     fillOpacity = opacity) %>%
    addPolylines(color = colour,
                 opacity=opacity,
                 weight=weight) %>% 
    addLabelOnlyMarkers(address_single$lon,
                        address_single$lat, 
                        label =  label_text,
                        labelOptions = labelOptions(noHide = T,
                                                    direction = label_position,
                                                    textOnly = T,
                                                    style=list("font-family" = font,
                                                               "font-weight"= font_weight,
                                                               "font-size"=font_size,
                                                               "text-indent"=text_indent))) 
  
  m
}


viz <- plot_route(my_punto_inicial,
                  my_punto_final,
                 how="car",
                 font="Courier",
                 label_position="right",
                 weight=1.5)

viz

#-------------------------------------------------------------------------------
#- este no acaba de chutar

library(webshot)
library(htmlwidgets)
library(magick)

get_route_svg <- function(viz, svg_name="Rplot.svg", zoom=3){
  # Saving the html generated
  saveWidget(viz, "temp.html", selfcontained = FALSE)
  
  webshot("temp.html",
          cliprect = "viewport",
          zoom=zoom,
          file = "Rplot.png") %>% 
    image_read() %>% 
    image_convert(format='svg') %>% 
    image_write('Rplot.svg')
  
  file.remove("temp.html")
  file.remove("Rplot.png")
  print(paste(svg_name,"written in",getwd()))
}

get_route_svg(viz)
