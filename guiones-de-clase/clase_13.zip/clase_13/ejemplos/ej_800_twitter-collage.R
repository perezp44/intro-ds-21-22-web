#- ejemplo twitter collage: 
#- https://www.jtimm.net/2020/01/05/2020-01-01a-year-in-twitter-photos/
library(rtweet)
library(tidyverse)

#- cuantas afotos en el collage ------------------------------------------------
files1 <- files[1:9]
no_rows <- 3
no_cols <- 3


#- crear una carpeta para guardar las fotos (hace falta) -----------------------
my_nombre_carpeta <- "afotos"  #- AQUI
fs::dir_create(my_nombre_carpeta)

#- cuenta de Twitter elegida ---------------------------------------------------
my_person <- "NachoVegasTwit" #- @NachoVegasTwit   #- AQUI
cuantos_tweets <- 500

NV_tweets <- rtweet::get_timeline(my_person, n = cuantos_tweets, check = FALSE) 
#rio::export(NV_tweets, "./datos/tweets_NV_7.rds")
#NV_tweets <- rio::import("./datos/tweets_NV_7.rds")


aa <- NV_tweets %>%
  mutate(created_at = as.Date(gsub(' .*$', '', created_at))) %>%
  filter(is_quote == 'FALSE' & 
           is_retweet == 'FALSE' & 
           created_at > '2019-01-02' &
           display_text_width > 0)


pics <- aa %>%
  filter(!is.na(media_url)) %>%
  select(media_url, created_at)

#setwd(local_pics)


my_fun_pics <- function (y) {
    magick::image_read(y) %>%
    magick::image_scale("1000") %>%
    magick::image_border('white', '10x10') %>%
    magick::image_write(path = here::here(my_nombre_carpeta,   gsub('^.*/', '', y)) )#%>%
  #magick::image_annotate(pics$created_at[y], font = 'Times', size = 50)
}
  
# my_pic <- "http://pbs.twimg.com/media/EoIiWQQXUAAKhF5.jpg"
# my_fun_pics(my_pic)

#lapply(pics$media_url, function (y) {
map(pics$media_url, my_fun_pics)
  


my_xx <- paste0("./", my_nombre_carpeta, "/")
files <- fs::dir_ls(my_xx)
files <- dir(my_nombre_carpeta , full.names = TRUE)
set.seed(11)
files <- sample(files, length(files))
# 
# files1 <- files[1:16]
# no_rows <- 4
# no_cols <- 4


fs::dir_create(here::here(my_nombre_carpeta, "columnas"))
make_column <- function(i, files, no_rows){
  magick::image_read(files[(i*no_rows+1):((i+1)*no_rows)]) %>%
    magick::image_append(stack = TRUE) %>%
    magick::image_write(here::here(my_nombre_carpeta, "columnas", paste0("cols", i, ".jpg")))}

#- hace columnas de no_rows a fotos
purrr::walk(0:(no_cols-1), make_column,  files = files1,
     no_rows = no_rows)


my_xx_dir <- paste0(my_nombre_carpeta, "/columnas/")
#- stack the columns-----------------------
magick::image_read(dir(my_xx_dir, full.names = TRUE)) %>% 
  magick::image_scale("500x1000") %>%
  magick::image_append(stack = FALSE) %>% 
  magick::image_write(here::here(my_xx_dir, "my_collage.jpg"))

