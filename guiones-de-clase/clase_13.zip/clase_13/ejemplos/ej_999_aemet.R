#- https://emf-creaf.github.io/meteospain/
#- antes estaba el pkg aemet: https://github.com/SevillaR/aemet
library(tidyverse)
library(ggforce)
library(sf)

library(keyring)
library(meteospain)  #- install.packages('meteospain')

#- Galicia ---------------------------------------------------------------------
mg_options <- meteogalicia_options(resolution = 'current_day')


aa <- get_meteo_from('meteogalicia', mg_options)


plot(aa)


estaciones <- get_stations_info_from('meteogalicia', mg_options)

#- AEMET -----------------------------------------------------------------------
#- hace falta una API key
library(keyring)
key_set('aemet') # A prompt asking for the secret (the API Key) will appear.

# current day, all stations
api_options <- aemet_options(
  resolution = 'current_day',
  api_key = key_get('aemet'))

estaciones_aemet <- get_stations_info_from('aemet', api_options)

api_options <- aemet_options(
  resolution = 'daily',
  start_date = as.Date('2021-11-26'),
  api_key = key_get('aemet')
)
spain_20200425 <- get_meteo_from('aemet', options = api_options)

spain_20200425 %>%
  units::drop_units() %>%
  ggplot() +
  geom_sf(aes(colour = mean_temperature)) +
  scale_colour_viridis_c()



#- Cataluña , tb necesita API --------------------------------------------------



#- Aficionados -----------------------------------------------------------------
#- Meteoclimatic is a non-professional (amateur) network of automatic meteorological stations. This network cover all Spain, but does not offer quality testing of the data.


api_options <- meteoclimatic_options(stations = 'ESCAT08')
api_options

estaciones_aficionadas <- get_stations_info_from('meteoclimatic', options = api_options)

