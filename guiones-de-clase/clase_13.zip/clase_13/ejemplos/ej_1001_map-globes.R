library(tidyverse)
library("covid19.analytics")
                 
df <- covid19.analytics::covid19.data
data(covid19.data)
#- covid19.analytics package ---------------------------------------------------
#- https://mponce0.github.io/covid19.analytics/
pueblos <- data.frame(
  Country = c("Spain", "Spain"),
  Province = c("Pancrudo", "Valencia"), 
  Long = c(-1.028781, -0.3756572),
  Lat = c(40.76175, 39.47534) )     
pueblos

live.map(data = pueblos, title = "Pancrudo y Valencia", no.legend = TRUE)


#- webgloble pkg ---------------------------------------------------------------
#- https://github.com/r-barnes/webglobe

library(webglobe)              #Load the library
data(quakes)                   #Load up some data

wg <- webglobe(immediate=TRUE) #Make a webglobe (should open a net browser)
Sys.sleep(10)                     #Wait for browser to start, or it won't work ()
#wg + wgpoints(quakes$lat, quakes$lon, size=5*quakes$mag) #Plot quakes
wg + wgpoints(pueblos$Lat, pueblos$Long) #Plot pueblos

wg + wgcamcenter(lat = 40.76175, lon =-1.028781, alt =8000)                    #Move camera
