#- https://www.mzes.uni-mannheim.de/socialsciencedatalab/article/studying-politics-wikipedia/

#library(WikipediR)  #- An R API wrapper for MediaWiki, optimised for the Wikimedia Foundation MediaWiki instances, such as Wikipedia.
#library(WikidataR)  #- An R API wrapper for the Wikidata store of semantic data.
library(pageviews)   #- An API client library for Wikimedia traffic data: https://github.com/ironholds/pageviews
library(tidyverse)


vignette("Accessing_Wikimedia_pageviews", package = "pageviews")

my_start <- "2021010100"
my_fecha <- "2021-12-08"
aa <- top_articles(project = "es.wikipedia", platform = "all",
                   start = as.Date(my_fecha), granularity = "daily")

#- pageviews:
my_start <- "2021010100"
my_end   <- "2021120800"

R_views <- article_pageviews(project = "en.wikipedia", article = "R (programming language)", 
                             user_type = "user",
                             start = my_start, end = my_end)


R_views_es <- article_pageviews(project = "es.wikipedia", article = "R (lenguaje de programación)",
                                user_type = "user",
                                start = my_start, end = my_end)

Phyton_views <- article_pageviews(project = "en.wikipedia", article = "Python (programming language)", 
                                  user_type = "user", 
                                  start = my_start, end = my_end)

Phyton_views_es <- article_pageviews(project = "es.wikipedia", article = "Python", 
                                     user_type = "user",  
                                     start = my_start, end = my_end)
zz <- R_views


str(R_views)

#- agrupamos visitas por meses
library(lubridate)

R_views <- R_views %>% 
  group_by(month = floor_date(date, "month")) %>% summarize(views_R = sum(views))

R_views_es <- R_views_es %>% 
  group_by(month = floor_date(date, "month")) %>% summarize(views_R_es = sum(views))

Phyton_views <- Phyton_views %>% 
  group_by(month = floor_date(date, "month")) %>% summarize(views_Phyton = sum(views))

Phyton_views_es <- Phyton_views_es %>% 
  group_by(month = floor_date(date, "month")) %>% summarize(views_Phyton_es = sum(views))

#- podriamos haberlo hecho con una función (o más facil con una pipe chain)
my_pipes <- . %>% group_by(month = floor_date(date, "month")) %>% summarize(views = sum(views))

my_pipes(zz)
zz %>% my_pipes

#- pongamos las 4 series juntas
df <- cbind(R_views, R_views_es, Phyton_views, Phyton_views_es) %>% janitor::clean_names()

df <- df %>% select(-c(month_2, month_3, month_4))

#- tb se podia hacer asín
df2 <- full_join(R_views, R_views_es) %>% full_join(Phyton_views) %>% full_join(Phyton_views_es)

#- veamos si España es +R q los English
df <- df %>% mutate(R_phy = views_r / views_phyton) %>%
             mutate(R_phy_es = views_r_es / views_phyton_es)

#- Hagamos un gráfico con las 4 series para ver su evolución... OK, pero .... ¿los datos están en formato TIDY? NO


#- están en formato tidy?? NO. Pues habrá q hacerlo TIDY **trabajo en clase**



#- ahora ya sí, un gráfico con las 4 series  **trabajo en clase**
