# Exploratory Data Analysis and Data Preparation with funModeling #

# Directorio de trabajo
#- setwd("C:/users/Jorge Segura/Desktop/Taller_Machine Learning")


# Improtar datos Churn.csv
library(readr)
churnTest <- read_csv("./ML_jorge-segura/churnTest.csv")
churnTrain <- read_csv("./ML_jorge-segura/churnTrain.csv")
Churn<-rbind(churnTrain, churnTest)

# Convertir en factores las varaibles character
labels(Churn)[[2]]
convert<-c(2,4:6,21)
Churn[,convert]<-data.frame(apply(Churn[convert],2,as.factor))
Churn<-as.data.frame(Churn)
churnTrain[,convert]<-data.frame(apply(churnTrain[convert],2,as.factor))
churnTest[,convert]<-data.frame(apply(churnTest[convert],2,as.factor))

#### Analisis Exploratorio ####

library(funModeling)
library(mlbench)
library(DataExplorer)

df_status(Churn)

# Hacemos gráfico de las variables numericas
plot_num(Churn[,-1])
plot_histogram(Churn[,-1])

# Principales estadísticas de las variables numericas
profiling_num(Churn[,-1])

# distribucion de frecuencias para una variable factor
freq(Churn$area_code)
freq(Churn$churn)

# Correlacion
correlation_table(Churn, "churn")
plot_correlation(Churn[,-1])
cor(Churn$total_day_minutes, Churn$total_day_charge)
precio<-Churn$total_day_charge/Churn$total_day_minutes
head(precio)

cross_plot(data=Churn, input=c("total_day_charge","number_customer_service_calls"), target = "churn")

plotar(data=Churn, input=c("total_day_charge","number_customer_service_calls"), target = "churn",
       plot_type = "boxplot")

#### Seleccionar varaibles con Boruta ####

library(Boruta)
library(ranger)
boruta.train <- Boruta(churn~., data =churnTrain, doTrace = 2)
print(boruta.train)

# Gr?fico de la Importancia de las Variables
plot(boruta.train, xlab = "", xaxt = "n")
lz<-lapply(1:ncol(boruta.train$ImpHistory),function(i)
  boruta.train$ImpHistory[is.finite(boruta.train$ImpHistory[,i]),i])
names(lz) <- colnames(boruta.train$ImpHistory)
Labels <- sort(sapply(lz,median))
axis(side = 1,las=2,labels = names(Labels),at = 1:ncol(boruta.train$ImpHistory), cex.axis = 0.7)

# Grafico del proceso de Boruta 
plotImpHistory(boruta.train)
# Estadisticas de Boruta con las que se hace el grafico
borutadf<-attStats(boruta.train)
print(borutadf)

# Seleccionar varaibles
# Train y Test deben ser data.frame
varia<-getSelectedAttributes(boruta.train, withTentative = TRUE)
Train<-churnTrain[,varia]
Test<-churnTest[,varia]
# Añadir la variable churn que debe ser factor
Train$churn<-churnTrain$churn
Test$churn<-churnTest$churn

# Se crea un data frame para guardar todas las predicciones
sol_churn<-churnTest[,c(1,21)]
sol_churn$churn<-as.factor(sol_churn$churn)

#### Modelizar y Predecir ####
library(caret)
library(e1071)
set.seed(2018)
trainctrl<-trainControl(method = "repeatedcv", number = 5, repeats = 3)

# Se entrena un modelo Naive Bayes con los datos de Train
model_01<-naiveBayes(churn~., data=Train)
model_01

# prediccion copn el modelo naive bayes
sol_churn$model_01<-predict(model_01, type = "raw", Test)[,2]
sol_churn$model_01_F<-as.factor(round(sol_churn$model_01))
levels(sol_churn$model_01_F)<-c("no","yes")
# Matriz de Confusion
cm_model_01<-table(sol_churn$churn, sol_churn$model_01_F)
confusionMatrix(cm_model_01)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_01", target = "churn")
cross_plot(data = sol_churn, input = "model_01", target = "churn")

# Model_02 arbol de decision
library(rpart)
library(rpart.plot)
model_02<-train(churn~., data=Train, method="rpart", trControl=trainctrl)
confusionMatrix.train(model_02)
model_002<-model_02$finalModel
rpart.plot(model_002, type = 2, fallen.leaves = T)

# Prediccion y matriz de confusion
sol_churn$model_02<-predict(model_02, type = "prob", Test)[,2]
sol_churn$model_02_F<-as.factor(round(sol_churn$model_02))
levels(sol_churn$model_02_F)<-c("no","yes")
cm_model_02<-table(sol_churn$churn, sol_churn$model_02_F)

confusionMatrix(cm_model_02)
# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_02", target = "churn")
cross_plot(data = sol_churn, input = "model_02", target = "churn")

# Model_03 bosque aleatorio
library(randomForest)
model_03<-train(churn~., data=Train, method="rf", trControl=trainctrl)
confusionMatrix.train(model_03)
varImp(model_03)
plot(varImp(model_03), main="Random Forest: Variable Importance" )

# Prediccion y matriz de confusion
sol_churn$model_03<-predict(model_03, type = "prob", Test)[,2]
sol_churn$model_03_F<-as.factor(round(sol_churn$model_03))
levels(sol_churn$model_03_F)<-c("no","yes")
cm_model_03<-table(sol_churn$churn, sol_churn$model_03_F)
confusionMatrix(cm_model_03)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_03", target = "churn")
cross_plot(data = sol_churn, input = "model_03", target = "churn")

# Model_04 XGBoost
library(xgboost)
library(plyr)
trainctrl_2<-trainControl(method = "repeatedcv", number = 5, repeats = 3,
                          #summaryFunction = twoClassSummary,
                          classProbs = TRUE,
                          allowParallel=T)

set.seed(2018)
model_04<-train(churn~., data=Train, method="xgbTree",
                trControl=trainctrl_2,
                verbose=T,
                metric="Kappa")
# Tarda dos o tres minutos
confusionMatrix.train(model_04)

# Prediccion y matriz de confusion
sol_churn$model_04<-predict(model_04, type = "prob", Test)[,2]
sol_churn$model_04_F<-as.factor(round(sol_churn$model_04))
levels(sol_churn$model_04_F)<-c("no","yes")
cm_model_04<-table(sol_churn$churn, sol_churn$model_04_F)
confusionMatrix(cm_model_04)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_04", target = "churn")
cross_plot(data = sol_churn, input = "model_04", target = "churn")

### Comparacion de los modelos ###
# Matriz de Confusion
cm_m1<-confusionMatrix(cm_model_01)
cm_m2<-confusionMatrix(cm_model_02)
cm_m3<-confusionMatrix(cm_model_03)
cm_m4<-confusionMatrix(cm_model_04)

# Precision General del Modelo
Accuracy<-c(cm_m1$overall[1],cm_m2$overall[1],cm_m3$overall[1],cm_m4$overall[1])

# Estadistico Kappa
Kappa<-c(cm_m1$overall[2],cm_m2$overall[2],cm_m3$overall[2],cm_m4$overall[2])

# Verdaderos Positivos
TP<-c(cm_m1$byClass[3],cm_m2$byClass[3],cm_m3$byClass[3],cm_m4$byClass[3])

# Verdaderos Negativos
TN<-c(cm_m1$byClass[4],cm_m2$byClass[4],cm_m3$byClass[4],cm_m4$byClass[4])

# Matriz de Evaluacion de los modelos
Evaluacion<-data.frame(cbind(Accuracy, Kappa, TP, TN))
row.names(Evaluacion)<-c("Naive Bayes", "Decision Tree", "Random Forest", "XGBoost")


#### Generar datos Sinteticos ####
# Generar datos con SMOTE
library(DMwR)
Train<-as.data.frame(Train)
data_smote<-SMOTE(churn~., Train, perc.over=400, perc.under=150)
table(data_smote$churn)

library(ggplot2)
ggplot(Train, aes(number_vmail_messages, total_day_charge))+geom_point(aes(shape=churn, color=churn))
ggplot(data_smote, aes(number_vmail_messages, total_day_charge))+geom_point(aes(shape=churn, color=churn))

# Se entrena un modelo Naive Bayes con los datos generados con SMOTE
model_05<-naiveBayes(churn~., data=data_smote)
model_05

# prediccion copn el modelo naive bayes (SMOTE)
sol_churn$model_05<-predict(model_05, type = "raw", Test)[,2]
sol_churn$model_05_F<-as.factor(round(sol_churn$model_05))
levels(sol_churn$model_05_F)<-c("no","yes")
# Matriz de Confusion
cm_model_05<-table(sol_churn$churn, sol_churn$model_05_F)
confusionMatrix(cm_model_05)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_05", target = "churn")
cross_plot(data = sol_churn, input = "model_05", target = "churn")

# Model_06 arbol de decision (SMOTE)
library(rpart)
library(rpart.plot)
model_06<-train(churn~., data=data_smote, method="rpart", trControl=trainctrl)
confusionMatrix.train(model_06)
model_006<-model_06$finalModel
rpart.plot(model_006, type = 2, fallen.leaves = T)

# Prediccion y matriz de confusion
sol_churn$model_06<-predict(model_06, type = "prob", Test)[,2]
sol_churn$model_06_F<-as.factor(round(sol_churn$model_06))
levels(sol_churn$model_06_F)<-c("no","yes")
cm_model_06<-table(sol_churn$churn, sol_churn$model_06_F)
confusionMatrix(cm_model_06)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_06", target = "churn")
cross_plot(data = sol_churn, input = "model_06", target = "churn")

# Model_07 bosque aleatorio (SMOTE)
library(randomForest)
model_07<-train(churn~., data=data_smote, method="rf", trControl=trainctrl)
confusionMatrix.train(model_07)
varImp(model_07)
plot(varImp(model_07), main="Random Forest: Variable Importance" )

# Prediccion y matriz de confusion
sol_churn$model_07<-predict(model_07, type = "prob", Test)[,2]
sol_churn$model_07_F<-as.factor(round(sol_churn$model_07))
levels(sol_churn$model_07_F)<-c("no","yes")
cm_model_07<-table(sol_churn$churn, sol_churn$model_07_F)
confusionMatrix(cm_model_07)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_07", target = "churn")
cross_plot(data = sol_churn, input = "model_07", target = "churn")

# Model_08 XGBoost (SMOTE)
library(xgboost)
library(plyr)
trainctrl_2<-trainControl(method = "repeatedcv", number = 5, repeats = 3,
                          #summaryFunction = twoClassSummary,
                          classProbs = TRUE,
                          allowParallel=T)

set.seed(2018)
model_08<-train(churn~., data=data_smote, method="xgbTree",
                trControl=trainctrl_2,
                verbose=T,
                metric="Kappa")
# Tarda dos o tres minutos
confusionMatrix.train(model_08)

# Prediccion y matriz de confusion
sol_churn$model_08<-predict(model_08, type = "prob", Test)[,2]
sol_churn$model_08_F<-as.factor(round(sol_churn$model_08))
levels(sol_churn$model_08_F)<-c("no","yes")
cm_model_08<-table(sol_churn$churn, sol_churn$model_08_F)
confusionMatrix(cm_model_08)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_08", target = "churn")
cross_plot(data = sol_churn, input = "model_08", target = "churn")

### Comparacion de los modelos con datos generados con SMOTE###
# Matriz de Confusion
cm_m5<-confusionMatrix(cm_model_05)
cm_m6<-confusionMatrix(cm_model_06)
cm_m7<-confusionMatrix(cm_model_07)
cm_m8<-confusionMatrix(cm_model_08)

# Precision General del Modelo
Accuracy<-c(cm_m5$overall[1],cm_m6$overall[1],cm_m7$overall[1],cm_m8$overall[1])

# Estadistico Kappa
Kappa<-c(cm_m5$overall[2],cm_m6$overall[2],cm_m7$overall[2],cm_m8$overall[2])

# Verdaderos Positivos
TP<-c(cm_m5$byClass[3],cm_m6$byClass[3],cm_m7$byClass[3],cm_m8$byClass[3])

# Verdaderos Negativos
TN<-c(cm_m5$byClass[4],cm_m6$byClass[4],cm_m7$byClass[4],cm_m8$byClass[4])

# Matriz de Evaluacion de los modelos generados con SMOTE
Evaluacion_2<-data.frame(cbind(Accuracy, Kappa, TP, TN))
row.names(Evaluacion_2)<-c("Naive Bayes (SMOTE)", "Decision Tree (SMOTE)", "Random Forest (SMOTE)", "XGBoost (SMOTE)")

# Añadir los nuevos resultados a los que habia en Evaluacion
Evaluacion<-rbind(Evaluacion, Evaluacion_2)

### Arbol de decision con Matriz de Costes ###
# Modelizacion con algoritmo rpart y matriz de costes
model_09<-rpart(churn~., data=Train, method = "class",
                parms = list(split="information", loss=matrix(c(0,5,1,0),byrow = TRUE, nrow=2)))
model_09
rpart.plot(model_09)

# Prediccion y matriz de confusion
sol_churn$model_09<-predict(model_09, type = "prob", Test)[,2]
sol_churn$model_09_F<-as.factor(round(sol_churn$model_09))
levels(sol_churn$model_09_F)<-c("no","yes")
cm_model_09<-table(sol_churn$churn, sol_churn$model_09_F)
confusionMatrix(cm_model_09)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_09", target = "churn")
cross_plot(data = sol_churn, input = "model_09", target = "churn")

# Cambio de ponderaciones para Radom Forest
sol_churn$model_10_F<-ifelse(sol_churn$model_03<0.2,"no","yes")
sol_churn$model_10_F<-as.factor(sol_churn$model_10_F)
cm_model_10<-table(sol_churn$churn, sol_churn$model_10_F)
confusionMatrix(cm_model_10)

# Cambio de ponderaciones para XGBoost
sol_churn$model_11_F<-ifelse(sol_churn$model_04<0.2,"no","yes")
sol_churn$model_11_F<-as.factor(sol_churn$model_11_F)
cm_model_11<-table(sol_churn$churn, sol_churn$model_11_F)
confusionMatrix(cm_model_11)

### Comparacion de los modelos con datos generados con SMOTE###
# Matriz de Confusion
cm_m9<-confusionMatrix(cm_model_09)
cm_m10<-confusionMatrix(cm_model_10)
cm_m11<-confusionMatrix(cm_model_11)

# Precision General del Modelo
Accuracy<-c(cm_m9$overall[1],cm_m10$overall[1],cm_m11$overall[1])
# Estadistico Kappa
Kappa<-c(cm_m9$overall[2],cm_m10$overall[2],cm_m11$overall[2])
# Verdaderos Positivos
TP<-c(cm_m9$byClass[3],cm_m10$byClass[3],cm_m11$byClass[3])
# Verdaderos Negativos
TN<-c(cm_m9$byClass[4],cm_m10$byClass[4],cm_m11$byClass[4])

# Matriz de Evaluacion de los modelos generados con matriz de costes
Evaluacion_3<-data.frame(cbind(Accuracy, Kappa, TP, TN))
row.names(Evaluacion_3)<-c("Decision Tree (Cost)", "Random Forest (Cost)", "XGBoost (Cost)")

# Añadir los nuevos resultados a los que habia en Evaluacion
Evaluacion<-rbind(Evaluacion, Evaluacion_3)


#### Random Forest Explainer ####
library(randomForest)
library(randomForestExplainer)

set.seed(2017)
forest<-randomForest(churn~., data=data_smote, localImp=TRUE)
forest
plot(forest, main = "Learning curve of the forest")

# Distribucion de la profundidad minima
min_depth_frame<-min_depth_distribution(forest)
# save(min_depth_frame, file="min_depth_frame.rda")
# load("min_depth_frame.rda")
head(min_depth_frame, n=10)

plot_min_depth_distribution(min_depth_frame)

plot_min_depth_distribution(min_depth_frame, mean_sample = "relevant_trees", k=15)

# Varias medidas de la importancia de las variables
importance_frame<-measure_importance(forest)
importance_frame

# Multi-way importance plot
plot_multi_way_importance(importance_frame, size_measure = "no_of_nodes")
plot_multi_way_importance(importance_frame, x_measure = "mse_increase", y_measure = "node_purity_increase",
                          size_measure = "p_value", no_of_labels = 5)

# Comparar medidas utilizando ggpairs
plot_importance_ggpairs(importance_frame)

plot_importance_rankings(importance_frame)

# Interaccion entre variables
vars<-important_variables(importance_frame, k=5, measures = c("mean_min_depth", "no_of_trees"))

interactions_frame<-min_depth_interactions(forest, vars)
head(interactions_frame[order(interactions_frame$occurrences, decreasing = TRUE), ])
plot_min_depth_interactions(interactions_frame)

interactions_frame_2<-min_depth_interactions(forest, vars, mean_sample = "relevant_trees",
                                             uncond_mean_sample = "relevant_trees")
plot_min_depth_interactions(interactions_frame_2)

plot_predict_interaction(forest, data_smote, "total_day_minutes", "number_customer_service_calls")

# Informe de randomForestExplainer automatico
explain_forest(forest, interactions = TRUE, data = data_smote)


#### XGBoost Explainer ####
library(xgboost)
train_3<-Train
# La varaible objetivo en el algoritmo xgboost tiene que ser numerica
# Los valores de la variable objetivo tienen que ser 0 y 1
train_3$churn<-as.numeric(train_3$churn)
train_3$churn<-replace(train_3$churn, train_3$churn==1, 0)
train_3$churn<-replace(train_3$churn, train_3$churn==2, 1)
# Generar las matrices para entrenar el modelo
xgb.train.data = xgb.DMatrix(data.matrix(train_3[,-14]), label = train_3[,14], missing = NA)

param <- list(objective = "binary:logistic", base_score = 0.5)
cv <- createFolds(train_3[,14], k = 10)
xgboost.cv <- xgb.cv(param=param, data = xgb.train.data, folds = cv, nrounds = 1500, early_stopping_rounds = 100, metrics='auc')
best_iteration <- xgboost.cv$best_iteration

xgb.model <- xgboost(param =param,  data = xgb.train.data, nrounds=best_iteration)
# Generar matriz para el conjunto de entrenamiento
xgb.test.data <- xgb.DMatrix(data.matrix(Test[,-14]), missing = NA)

# Prediccion modelo_12 XGBoost
sol_churn$model_12<-predict(xgb.model, xgb.test.data)
sol_churn$model_12_F<-as.factor(round(sol_churn$model_12))
levels(sol_churn$model_12_F)<-c("no","yes")
cm_model_12<-table(sol_churn$churn, sol_churn$model_12_F)
confusionMatrix(cm_model_12)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_12", target = "churn")
cross_plot(data = sol_churn, input = "model_12", target = "churn")

# Importancia de las variables
col_names = attr(xgb.train.data, ".Dimnames")[[2]]
imp = xgb.importance(col_names, xgb.model)
# xgb.plot.importance(head(imp,10))
xgb.ggplot.importance(imp)+theme_minimal()

#### Train XGBoost con SMOTE ####
train_4<-data_smote
train_4$churn<-as.numeric(train_4$churn)
train_4$churn<-replace(train_4$churn, train_4$churn==1, 0)
train_4$churn<-replace(train_4$churn, train_4$churn==2, 1)
xgb.train.data.smote<-xgb.DMatrix(data.matrix(train_4[,-14]), label = train_4[,14], missing = NA)

cv2 <- createFolds(train_4[,14], k = 10)
xgboost.cv.smote <- xgb.cv(param=param, data = xgb.train.data.smote, folds = cv2, nrounds = 1500, early_stopping_rounds = 100, metrics='auc')
best_iteration_smote <- xgboost.cv.smote$best_iteration

xgb.smote.model<-xgboost(param =param,  data = xgb.train.data.smote, nrounds=best_iteration_smote)

xgb.test.data.smote<-xgb.DMatrix(data.matrix(Test[,-14]), missing = NA)
sol_churn$model_13<-predict(xgb.smote.model, xgb.test.data.smote)
sol_churn$model_13_F<-as.factor(round(sol_churn$model_13))
levels(sol_churn$model_13_F)<-c("no","yes")
cm_model_13<-table(sol_churn$churn, sol_churn$model_13_F)
confusionMatrix(cm_model_13)

# Generar graficos de la prediccion
gain_lift(data = sol_churn, score = "model_13", target = "churn")
cross_plot(data = sol_churn, input = "model_13", target = "churn")

# Importancia de las variables con SMOTE
col_names = attr(xgb.train.data.smote, ".Dimnames")[[2]]
imp2 = xgb.importance(col_names, xgb.smote.model)
# xgb.plot.importance(head(imp2,10))
xgb.ggplot.importance(imp2)+theme_minimal()

### Comparacion de los modelos con datos generados con SMOTE###
# Matriz de Confusion
cm_m12<-confusionMatrix(cm_model_12)
cm_m13<-confusionMatrix(cm_model_13)

# Precision General del Modelo
Accuracy<-c(cm_m12$overall[1],cm_m13$overall[1])
# Estadistico Kappa
Kappa<-c(cm_m12$overall[2],cm_m13$overall[2])
# Verdaderos Positivos
TP<-c(cm_m12$byClass[3],cm_m13$byClass[3])
# Verdaderos Negativos
TN<-c(cm_m12$byClass[4],cm_m13$byClass[4])

# Matriz de Evaluacion de los modelos generados con matriz de costes
Evaluacion_4<-data.frame(cbind(Accuracy, Kappa, TP, TN))
row.names(Evaluacion_4)<-c("XGBoost (CV)", "XGBoost (CV-SMOTE)")

# Añadir los nuevos resultados a los que habia en Evaluacion
Evaluacion<-rbind(Evaluacion, Evaluacion_4)

#### The XGBoost Explainer con SMOTE ####
library(xgboostExplainer)
explainer2<-buildExplainer(xgb.smote.model, xgb.train.data.smote, type="binary", base_score = 0.5)
pred.breakdown<-explainPredictions(xgb.smote.model, explainer2, xgb.test.data.smote)

cat('Breakdown Complete','\n')
weights2 = rowSums(pred.breakdown)
pred.xgb2 = 1/(1+exp(-weights2))
cat(max(sol_churn$model_13-pred.xgb2),'\n')

go_out<-which(sol_churn$model_13>0.5)
n2<-length(go_out)
output2<-matrix(1:(16*n2),ncol=16,nrow=n2)
output2<-as.data.frame(output2)
for(i in 1:n2){
  idx_to_get_2<-as.integer(go_out[i])
  BBB<-showWaterfall(xgb.smote.model, explainer2, xgb.test.data.smote, data.matrix(Test[,-14]) ,idx_to_get_2, type = "binary")$data
  b2<-dim(BBB)[1]
  BBB$x<-as.character(BBB$x)
  BBB<-within(data=BBB, x<-data.frame(do.call('rbind',strsplit(as.character(x),"=",fixed=TRUE))))
  output2[i,]<-c(BBB[b2,2], as.character(BBB$x$X1[2]), as.character(BBB$x$X2[2]), BBB$y[2],
                 as.character(BBB$x$X1[3]), as.character(BBB$x$X2[3]), BBB$y[3],
                 as.character(BBB$x$X1[4]), as.character(BBB$x$X2[4]), BBB$y[4],
                 as.character(BBB$x$X1[5]), as.character(BBB$x$X2[5]), BBB$y[5],
                 as.character(BBB$x$X1[6]), as.character(BBB$x$X2[6]), BBB$y[6])
}

# Grafico de dos clientes
idx_to_get_3<-as.integer(2)
showWaterfall(xgb.smote.model, explainer2, xgb.test.data.smote, data.matrix(Test[,-14]) ,idx_to_get_3, type = "binary")
idx_to_get_4<-as.integer(40)
showWaterfall(xgb.smote.model, explainer2, xgb.test.data.smote, data.matrix(Test[,-14]) ,idx_to_get_4, type = "binary")

# Positivo que incrementa la probabilidad de fuga: Intervenir
# Negativo que reduce la probabildiad de fuga: No intervenir
output2$V1<-as.double(output2$V1)
output2$prob<-1/(1+exp(-output2$V1))
output2$customerID<-as.matrix(sol_churn[go_out,1])

# La salida de showWaterfall son todo caracteres
# se cmabia a factor o numerico para procesar los datos
convert2<-c(2,5,8,11,14)
output2[,convert2]<-data.frame(apply(output2[convert2],2,as.factor))
convert3<-c(3,4,6,7,9,10,12,13,15,16)
output2[,convert3]<-data.frame(apply(output2[convert3],2,as.double))

# Importancia de las varaibles para la fuga de clientes
# segun el modelo ajustado
var_1<-data.frame(table(output2$V2[output2$V4>0]))
var_2<-data.frame(table(output2$V5[output2$V7>0]))
var_3<-data.frame(table(output2$V8[output2$V10>0]))
var_4<-data.frame(table(output2$V11[output2$V13>0]))
var_5<-data.frame(table(output2$V14[output2$V16>0]))

library(dplyr)
var_mark<-full_join(var_1,var_2, by="Var1")
var_mark<-full_join(var_mark, var_3, by="Var1")
var_mark<-full_join(var_mark, var_4, by="Var1")
var_mark<-full_join(var_mark, var_5, by="Var1")
var_mark[is.na(var_mark)]<-0 # Imputar cero a los NA

# Cambiar nombre de las variables
names(var_mark)<-c("Variables","Var1","Var2","Var3","Var4","Var5")
var_mark<-var_mark[order(-var_mark[,2],var_mark[,1]),]
var_mark$Total<-rowSums(var_mark[,2:6])
var_mark

# Graficos de las variables
# par(mfrow=c(2,3)) No va con ggplot2
ggplot(var_mark, aes(x=Variables, y=Var1))+geom_bar(stat = "identity")+coord_flip()
ggplot(var_mark, aes(x=Variables, y=Var2))+geom_bar(stat = "identity")+coord_flip()
ggplot(var_mark, aes(x=Variables, y=Var3))+geom_bar(stat = "identity")+coord_flip()
ggplot(var_mark, aes(x=Variables, y=Var4))+geom_bar(stat = "identity")+coord_flip()
ggplot(var_mark, aes(x=Variables, y=Var5))+geom_bar(stat = "identity")+coord_flip()

ggplot(var_mark, aes(x=Variables, y=Total))+geom_bar(stat = "identity")+coord_flip()

# AUC y Curva ROC
library(ROCR)
m13_pred<-prediction(sol_churn$model_13, sol_churn$churn)
m13_perf<-performance(m13_pred, "tpr", "fpr")
plot(m13_perf, lwd=2, colorize=TRUE, main="ROC Model XGBoost (CV-SMOTE)")
lines(x=c(0,1), y=c(0,1), col="red", lwd=1, lty=3)
m13_auc<-round(performance(m13_pred, measure = "auc")@y.values[[1]],4)

# Calculo del RMSE
# no pueden estar activado a la vez ROCR Y ModelMetrics
library(ModelMetrics)
rmse_03<-rmse(sol_churn$model_03_F, sol_churn$churn)
rmse_13<-rmse(sol_churn$model_13_F, sol_churn$churn)

