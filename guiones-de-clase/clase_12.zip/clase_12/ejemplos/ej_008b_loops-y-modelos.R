#- ejemplo: loops y modelos
library(tidyverse)   #- para poder usar the pipe

#- nuestro primer loop --------------------------------------------------------
for (ii in 1:5) {
  print(ii)
}

#- ejemplo: imagina q queremos calcular la media de las variables de iris. Podemos hacerlo de varias maneras:

#- 1) a lo bruto ---------------------------------------------------------------
mean_vec <- vector()
mean_vec[1] <- mean(iris$Sepal.Length)
mean_vec[2] <- mean(iris$Sepal.Width)
mean_vec[3] <- mean(iris$Petal.Length)
mean_vec[4] <- mean(iris$Petal.Width)
mean_vec[5] <- mean(iris$Species)

mean_vec

#- 2) con un loop --------------------------------------------------------------
mean_vec <- vector()

for (i in 1:ncol(iris)) {
  mean_vec[[i]] <- mean(iris[[i]])
}

mean_vec

#- con loop pero un poco mejor -------------------------------------------------
mean_vec <- vector("double", ncol(iris)) #- primero creamos el vector para almacenar las medias

for (i in seq_along(iris)) {         #- es mejor, mas seguro, usar seq_along()
  mean_vec[[i]] <- mean(iris[[i]])
}

mean_vec


#- 3) con el pkg dplyr ---------------------------------------------------------
mean_vec <- iris  %>% summarise(across(1:5, mean) ) 

mean_vec <- iris  %>% summarise(across(everything(), mean) ) 

mean_vec <- iris  %>% summarise(across(where(is.numeric), mean)) 

mean_vec <- mean_vec #- unlist() si quisieramos  pasarlo  a vector


#- 4) con la familia de funciones *apply's  de R-base --------------------------

#- con lapply()
mean_vec <- lapply(iris, mean) %>% as.data.frame()   #- el output de lapply es una lista, la paso a df

#- con sapply()
mean_vec <- sapply(iris, mean) %>% as.data.frame()    #- el output de sapply es un vector


#- 5) con purrr ----------------------------------------------------------------
mean_vec <- iris %>% map(mean) %>% as.data.frame()    #- map() devuelve una lista

mean_vec <- mtcars %>% map_dbl(mean)                   #- map_dbl() lo pasa directamente a vector numerico)






#- Un ejemplo de uso de loops --------------------------------------------------

#- estimamos un modelo lineal con lm()
library(tidyverse)
df <- rio::import(here::here("datos", "df_bebes_2017.rds"))     #- 374.933 x 13

#- map() es muy potente
df %>% map(is.na) %>% map(sum) %>% as_tibble

df %>% map(is.na) %>% map(sum) %>% map(~ . / nrow(df)) %>% bind_cols()

#- quitemos los NA's
df <- df %>% drop_na()

my_model <- lm(PESON1 ~ SEMANAS + EDADM + SEXO1 + CESAREA.f, data = df)
summary(my_model)


#- nuestro segundo loop --------------------------------------------------------
#- quiero estimar el mismo modelo pero para cada país de nacimiento de la madre con mas de 3000 bebes

zz <- df %>% group_by(MUNREM) %>% 
             mutate(NN_en_muni = n()) %>% 
             filter(NN_en_muni >= 3000) %>% distinct(MUNREM) %>% pull()  #- salen solo 4 municipios

#- lo hago didáctico (!!)
my_list_models <- list()

for (ii in 1:length(zz)) {
  print(ii)
    dfx <- df %>% filter(MUNREM == zz[ii])
    my_model <- lm(PESON1 ~ SEMANAS + EDADM + SEXO1, data = dfx)
    my_list_models[[ii]] <- my_model
}


#- varios enfoques n------------------------------------------------------------
aa <- df %>% group_by(MUNREM) %>% group_split()  #- group_split()

aa <- df %>% nest_by(MUNREM)   #- nest/()
aa <- df %>% group_by(MUNREM) %>% mutate(NN = n())  %>% ungroup() %>% nest_by(MUNREM, NN) 



#- con broom -------------------------------------------------------------------
library(broom)
df_zz <- df %>% filter(MUNREM %in% zz)    #- solo 4 municipios

bb <- df_zz %>% group_by(MUNREM) %>% do(tidy(lm(PESON1 ~ SEMANAS, .)))


#- con map() -------------------------------------------------------------------
cc <- df_zz %>%
  split(.$MUNREM) %>%
  map(~ lm(PESON1 ~ SEMANAS, data = .x)) %>%
  map(summary) %>%
  map_dbl("r.squared")


dd <- df_zz %>%
  split(.$MUNREM) %>%
  map(~ lm(PESON1 ~ SEMANAS, data = .x)) %>%
  map_dfr(~ as.data.frame(t(as.matrix(coef(.)))))
