#- Geocoding: 
#- hay varios paquetes para geolocalizar:
#- tidygeocoder, tmaptools, ggmap, opencage, hereR

library(tidyverse)

#- tidygeocoder ----------------------------------------------------------------
library(tidygeocoder)

#- geolocalizamos el SFPIE, con el pkg tidygeocoder
df <- data.frame(adress = "Servei de Formacio Permanent", 
                 street = "Serpis 29", 
                 city = "Valencia", 
                 country = "Spain")

df <- df %>% mutate(text_to_geocode = paste(street, city, country, sep = ", "))

#- tidygeocoder::geocode()
df <- df %>% tidygeocoder::geocode(text_to_geocode, method = "osm")


#- leaflet ---------------
#- hacemos un mapa con el paquete leaflet 
library(leaflet)

map <- leaflet::leaflet() %>%
       leaflet::addTiles() %>% 
       leaflet::setView(lng = df$long, lat = df$lat, zoom = 16) 
map


#- añadimos markers al mapa
map <- map %>% 
       leaflet::addMarkers(lng = df$long, lat = df$lat, popup = "SFPIE") %>% 
       leaflet::addPopups(lng = df$long, lat = df$lat, popup = "SFPIE") 
map


#- vamos a ponerle una imagen al mapa 
img <-  "https://www.uv.es/recursos/fatwirepub/ccurl/12/318/P01.jpg"
img <-  "./imagenes/R-logo.png"

library(leafpop) 
map2 <- map %>% 
  leaflet::addCircleMarkers(lng = df$long, lat = df$lat, group = "pnt") %>%
  leafpop::addPopupImages(img, group = "pnt", width = 200, height = 150, tootip = TRUE)

map2

#- se pueden poner muuuchos más elementos: https://rstudio.github.io/leaflet/basemaps.html
#- hay muchos "providers" de tiles o mapas : http://leaflet-extras.github.io/leaflet-providers/preview/
map2 %>% addProviderTiles(providers$Stamen.Toner)
map2 %>% addProviderTiles(providers$Stamen.Terrain)
map2 %>% addProviderTiles(providers$Esri.NatGeoWorldMap)

map2 %>% addProviderTiles(providers$MtbMap) #- carril bici


#- tmap ------------------------------------------------------------------------
#- help(package = "tmaptools")
library(tmaptools)

aa   <- tmaptools::geocode_OSM("Pancrudo")
aa_1 <- tmaptools::geocode_OSM("Pancrudo", details = TRUE, as.data.frame = TRUE, as.sf = TRUE)


# change to interactive mode
library(tmap)
tmap::tmap_mode("view")

#- ver si ha acertado la geolocalización
tmap::tm_shape(aa_1) + tmap::tm_dots(col = "blue") 



#- opencage pkg ----------------------------------------------------------------
#- hace falta API key
#- https://docs.ropensci.org/opencage/
library(opencage)   #- remotes::install_github("ropensci/opencage")

#- hereR pkg -------------------------------------------------------------------
#- https://github.com/munterfi/hereR




#- el código de GGMAP, #- YA NO FUNCIONA, has de estar registrado
#- ggmap pkg -------------------------------------------------------------------
# https://www.nceas.ucsb.edu/~frazier/RSpatialGuides/ggmap/ggmapCheatsheet.pdf

library(tidyverse)

library(ggmap)
myLocation <- "Aulario sur Tarongers Valencia"
myMap <- get_map(location = myLocation,  source = "google", crop = FALSE, zoom = 16)
ggmap(myMap)



aa <- geocode("Aulario sur Tarongers Valencia", output='more')

library(leaflet)
m <- leaflet() %>% addTiles()
m %>% setView(lng = aa[1] , lat = aa[2], zoom = 13) %>% 
  addMarkers(lng = aa[[1]] , lat = aa[[2]], popup = "Nos vemos el viernes en el curso. Aula S513") %>%  addTiles()

#- seguramente no os funcionará xq hace falta estar registrado en las APIs de Google
#- https://github.com/dkahle/ggmap
#- https://www.datanalytics.com/libro_r/introduccion-a-ggmap.html
library(ggmap)

#- geolocalización
UV_adress <- ggmap::geocode("Avenida de los Naranjos,  Facultat de Economía, Valencia, España", 
                            source = "google")

#- geolocalización inversa
revgeocode(as.numeric(UV_adress))

#- devuelve un "mapa"
map.UV_adress <- ggmap::get_map(location = as.numeric(UV_adress),
                                color = "color",
                                maptype = "roadmap",
                                scale = 2, zoom = 16)

#- graficamos el mapa
ggmap(map.UV_adress) + geom_point(aes(x = lon, y = lat),
                                  data = UV_adress, colour = 'red',
                                  size = 4)


#- una ruta
mapa <- get_map("Valencia, España", source = "stamen", maptype = "toner", zoom = 12)
ggmap(mapa)
ruta <- route(from = "Facultad de Economia, valencia", to = "Playa Malvarrosa, Valencia")

#- no chuta
ggmap(mapa) + 
  geom_path(aes(x = startLon, y = startLat, xend = endLon, yend = endLat),
            colour = "red", size = 2, data = ruta)




