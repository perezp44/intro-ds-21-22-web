#- script para procesar datos de la EPA
#- https://www.ine.es/dyngs/INEbase/es/operacion.htm?c=Estadistica_C&cid=1254736176918&menu=ultiDatos&idp=1254735976595

library(tidyverse)
library(sf)

#- hay datos en tablas y datos completos (los microdatos)


#- tablas ----------------------------------------------------------------------
#- por ejemplo la primera: Tasas de paro por distintos grupos de edad, sexo y comunidad autónoma
#- se puede descargar en varios formatos. Por ejemplo lo descargaré en .csv, .xlsx y pcaxis
#- https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1
#- https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1

#- en csv
#- salen decentes y en formato ancho
my_url <- "https://www.ine.es/jaxiT3/files/t/es/csv_bdsc/4247.csv?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.csv")
df_csv <- rio::import("./pruebas/epa_tab_1.csv")

#- en xlsx ---------------------------------------------------------------------
#- bueno, no salen decentes, habría que arreglarlos
#- quizas para vosotros sea mejor arreglarlos en Excel (!!!!!)
my_url <- "https://www.ine.es/jaxiT3/files/t/es/xlsx/4247.xlsx?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.xlsx")
df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx")

#- se pueden arreglar, pero ....
df_xlsx <- rio::import("./pruebas/epa_tab_1.xlsx", skip = 7)
#- habria q pasarlo a largo (y lo complica el hecho de que Total, H y M)



#- en pcaxis -------------------------------------------------------------------
#- salen decentes y en formato ancho
library(pxR) #- install.package("pxR")

my_url <- "https://www.ine.es/jaxiT3/files/t/es/px/4247.px?nocab=1"
curl::curl_download(my_url, "./pruebas/epa_tab_1.px")
df_px <- pxR::read.px("./pruebas/epa_tab_1.px") %>% as.data.frame 


#- microdatos ------------------------------------------------------------------
#- es otra historia (algo diré en clase)

dicc <- rio::import("https://www.ine.es/ftp/microdatos/epa/dr_EPA_2021.xlsx")


#- abrimos ficheros en varios formatos -----------------------------------------
#- no funcionará xq no hemos bajado esos ficheros
epa_sas <- haven::read_sas("tmp/SAS/epa_2020t3.sas7bdat", NULL)
epa_spss <- haven::read_sav("tmp/SPSS/EPA_2020T3.sav")
epa_stata <- haven::read_dta("tmp/STATA/EPA_2020T3.dta")
epa_csv <- readr::read_delim("tmp/CSV/EPA_2020T3.csv", "\t", escape_double = FALSE, locale = locale(date_names = "es"), trim_ws = TRUE)





#- vamos a arreglar/usar una tabla ---------------------------------------------
rm(list= ls())

df_csv <- rio::import("./pruebas/epa_tab_1.csv")
names(df_csv)

df <- janitor::clean_names(df_csv) 
names(df)

#- vemos q hay en la tabla
df_bb <- pjpv2020.01::pjp_f_valores_unicos(df)

df <- df %>% 
  dplyr::rename(CCAA = comunidades_y_ciudades_autonomas) %>% 
  filter(sexo == "Ambos sexos") %>% 
  filter(edad == "Total") 

#- pasamos a fecha
df <- df %>% 
  mutate(fecha = lubridate::yq(periodo)) 

#- para ver como se almacenan realmente las fechas
df_bb <- pjpv2020.01::pjp_f_valores_unicos(df)


#- me quedo con los totales españoles ------------------------------------------
#- y hago un gráfico chapucero
df_esp <- df %>% 
  filter(CCAA == "Total Nacional") %>% 
  select(-c(edad, sexo))

ggplot(df_esp, aes(x = fecha, y = total, group = 1)) +
  geom_line() + geom_point()


#- ahora una coropleta
df_ccaa <- df %>% filter(CCAA != "Total Nacional") %>% select(-c(edad, sexo))

df_ccaa <- df_ccaa %>% 
  tidyr::separate(CCAA, sep = " ", into = c("ine_ccaa", "ine_ccaa.n"), extra = "merge") %>% 
  select(- ine_ccaa.n)

  
#- cargo geometrías de CCAA
library(sf)
library(tidyverse)
df_geo_prov <- readr::read_rds(here::here("datos", "geo_prov_2020_LAU2_canarias.rds"))
df_geo_ccaa <- df_geo_prov %>% group_by(ine_ccaa) %>% dplyr::summarize()

head(df_geo_ccaa)

df_geo_ccaa <- cbind(df_geo_ccaa, st_coordinates(st_centroid(df_geo_ccaa$geometry)))

df_ok <- left_join(df_ccaa, df_geo_ccaa)

df_ok_ok <- df_ok %>% filter(fecha == max(fecha))


#- basic plot
p <- ggplot() + 
  geom_sf(data = df_ok_ok, 
          aes(geometry = geometry, fill = total), 
          color = "white", size = 0.09) 

p

#- better
p <- ggplot() + 
  geom_sf(data = df_ok_ok, 
          aes(geometry = geometry), fill = "antiquewhite", 
          color = "black", size = 0.09) +
  geom_text(data = df_ok_ok, aes(x = X, y = Y, label = total), #- v. continua
            color = "black",  
            check_overlap = TRUE, size = 3)  #- fontface = "bold"

p

