#- ggigraph: gráficos dinámicos con ggplot2
#- https://davidgohel.github.io/ggiraph/index.html
#- ejemplos:
library(tidyverse)
library(ggiraph)

#- Instead of using geom_point, use geom_point_interactive, instead of using geom_sf, use geom_sf_interactive… Provide at least one of the aesthetics tooltip, data_id and onclick to create interactive elements.

data <- mtcars
data$carname <- row.names(data)

gg_point = ggplot(data = data) +
  geom_point_interactive(aes(x = wt, y = qsec, color = disp,
                             tooltip = carname, data_id = carname)) + 
  theme_minimal()

girafe(ggobj = gg_point)


#- chulo!! señalas en un gráfico y tb ves la posición en otro gráfico 
library(patchwork)

mtcars <- mtcars
mtcars$tooltip <- rownames(mtcars)

gg1 <- ggplot(mtcars) +
  geom_point_interactive(aes(x = drat, y = wt, color = qsec, 
                             tooltip = tooltip, data_id = tooltip), size = 4) 

gg2 <- ggplot(mtcars) +
  geom_point_interactive(aes(x = qsec, y = disp, color = mpg, 
                             tooltip = tooltip, data_id = tooltip), size = 4)

girafe(code = print(gg1 + gg2), width_svg = 8, height_svg = 4)
