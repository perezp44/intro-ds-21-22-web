#- https://www.r-bloggers.com/merging-spatial-buffers-in-r/
#--------------------------------------------------------- Valencia
my_location <- "Valencia, Spain"
my_type_building <- "university"  #- university, hospital
my_type_key <- "building"  #- building, amenity

library(osmdata)
library(rgdal) ; library(maptools) ; library(rgeos)
library(tidyverse)

q0 <- opq(bbox = my_location, timeout = 60)
q1 <- add_osm_feature(q0, key = my_type_key, value = my_type_building)
x <- osmdata_sp(q1)

library(leaflet)

spChFIDs(x$osm_polygons) <- 1:nrow(x$osm_polygons@data)
cent <- gCentroid(x$osm_polygons, byid = TRUE)
leaflet(cent) %>% addTiles() %>% addCircles()

#- learning OSM ----------------------------------------------------------------

aa <- osmdata::available_features()  %>% as.data.frame()      #- a list of all features
bb <- osmdata::available_tags("highway") %>% as.data.frame()    #- all tags of a feature via osmdata
bb <- osmdata::available_tags("amenity") %>% as.data.frame()    #- all tags of a feature via osmdata

#- una query
my_city <- "Valencia, Spain"
streets <- getbb(my_city)%>% opq() %>%
  add_osm_feature(key = "highway", 
                  value = c("motorway", "primary", "secondary", "tertiary")) %>% osmdata_sf()


str(streets, max.level = 1)
zz_4 <- streets[[4]]  #- osm_points (pero no se muy bien qué son)
zz_5 <- streets[[5]]  #- osm_lines
zz_6 <- streets[[6]]  #- osm_polygons


ggplot() + geom_sf(data = zz_6,  aes(geometry = geometry), color = "black") +
  geom_sf(data = zz_5,  aes(geometry = geometry), color = "red", size = 1) +
  geom_sf(data = zz_4,  aes(geometry = geometry), color = "green", size = 0.1, alpha = 0.02)
